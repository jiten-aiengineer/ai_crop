"""Private administration API for the Crop Life AI operations portal.

This module never performs browser authentication. The browser signs in through
the Next.js Microsoft Entra BFF, which supplies a trusted employee identity on
the loopback-only request. All catalogue mutations remain approval requests
until an authorised employee approves them.
"""

import hmac
import hashlib
import base64
import json
import smtplib
import secrets
import re
from email.message import EmailMessage
from datetime import date, datetime
from decimal import Decimal
from zoneinfo import ZoneInfo
from typing import Annotated, Any, Literal, Optional
from uuid import UUID, uuid4
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
import csv
import io
import html

from fastapi import APIRouter, Depends, Header, HTTPException, Query, UploadFile, File, Response
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel, Field, field_validator
from psycopg.types.json import Jsonb

from .config import (
    ADMIN_ALLOWED_EMAIL_DOMAIN, ADMIN_GATEWAY_TOKEN, PORTAL_INVITE_EMAIL_FROM,
    PORTAL_INVITE_URL, SMTP_HOST, SMTP_PASSWORD, SMTP_PORT, SMTP_USERNAME,
    SMTP_USE_TLS, GPU_TRAINING_SERVICE_URL, GPU_TRAINING_SERVICE_TOKEN,
    MODEL_TRAINING_AUTOSTART,
    MODEL_TRAINING_MIN_NEW_CASES, MODEL_PIPELINE_MIN_CONFIDENCE,
    MODEL_PIPELINE_MIN_ISSUE_SIMILARITY, MODEL_AUTO_DEPLOY_ENABLED,
    MODEL_AUTO_PROMOTE_MIN_ACCURACY, MODEL_AUTO_PROMOTE_MIN_MACRO_F1,
    MODEL_AUTO_PROMOTE_MIN_ISSUE_ACCURACY,
    GEMMA_MODEL, GEMINI_SHADOW_ENABLED, GEMINI_SHADOW_MODEL,
    QWEN_BASE_URL, QWEN_ENABLED, QWEN_GPU_INSTANCE_ID, QWEN_MODEL,
    QWEN_SHADOW_MODE,
)
from .continuous_training import run_pipeline_cycle
from .db import connection


router = APIRouter(prefix="/api/v1/admin", tags=["admin"])
_REFERRAL_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

CATALOGUE_MANAGER_ROLES = {"catalog_editor", "manager", "catalogue_manager", "senior_catalogue_manager", "managing_director", "product_approver"}
SENIOR_CATALOGUE_MANAGER_ROLES = {"senior_catalogue_manager"}
# Product records are company knowledge. A senior manager may validate a
# proposal, but only the protected Super Administrator account can release a
# validated catalogue change into the live farmer application.
FINAL_CATALOGUE_PUBLISHER_ROLES = {"super_admin"}
MAPPING_PUBLISHER_ROLES = {"mapping_approver", "senior_catalogue_manager", "managing_director"}
CATALOGUE_READ_ROLES = CATALOGUE_MANAGER_ROLES | {
    "mapping_approver", "expert_review_approver", "employee_access_approver"
}
ADMIN_READ_ROLES = CATALOGUE_READ_ROLES | {"super_admin"}
INSPECTION_REVIEW_ROLES = {"manager", "expert_review_approver", "senior_catalogue_manager", "managing_director"}
MODEL_PIPELINE_CONTROL_ROLES = {"super_admin"}
# The legacy role code is retained for safe migration, but its active purpose
# is inspection quality review. It may remove unsuitable DB + S3 evidence; it
# does not approve cases for the automatic training dataset.
INSPECTION_DELETE_ROLES = {"super_admin", "expert_review_approver"}
SALES_ACTIVITY_ROLES = {"manager", "senior_catalogue_manager", "managing_director"}
DEALER_WRITE_ROLES = SALES_ACTIVITY_ROLES | {"catalogue_manager"}
DEALER_ARCHIVE_ROLES = {"managing_director"}
ASSIGNABLE_ROLE_CODES = {
    "field_employee", "manager", "catalog_editor", "catalogue_manager",
    "senior_catalogue_manager", "managing_director", "product_approver",
    "mapping_approver", "expert_review_approver", "employee_access_approver",
}


class AdminIdentity(BaseModel):
    id: UUID
    employee_code: str
    full_name: str
    email: str
    roles: list[str]
    is_test_identity: bool = False


class CatalogueProductInput(BaseModel):
    product_id: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]{1,98}$")
    name: str = Field(min_length=2, max_length=180)
    category: str = Field(min_length=2, max_length=160)
    common_name: str = Field(default="", max_length=4000)
    formulation: str = Field(default="", max_length=160)
    dose: str = Field(default="", max_length=4000)
    use_benefits: str = Field(default="", max_length=8000)
    packing: str = Field(default="", max_length=2000)
    price_per_pack: Decimal | None = Field(default=None, ge=0, max_digits=10, decimal_places=2)
    application_method: str = Field(default="", max_length=4000)
    safety_information: str = Field(default="", max_length=8000)
    image_path: str = Field(default="", max_length=500)
    source_page: int | None = Field(default=None, ge=1, le=10_000)
    catalogue_version: str = Field(default="Admin catalogue", max_length=160)
    # Inactive products stay in the controlled catalogue, but the farmer-facing
    # recommendation engine excludes them until they are reactivated and approved.
    status: Literal["active", "inactive"] = "active"

    @field_validator("image_path")
    @classmethod
    def trusted_product_image_path(cls, value: str) -> str:
        value = value.strip()
        if value and not (re.fullmatch(r"/products/[A-Za-z0-9._-]+\.(?:jpg|jpeg|png|webp)", value, re.IGNORECASE)
                          or re.fullmatch(r"s3:product-images/[A-Za-z0-9][A-Za-z0-9._/-]*\.(?:jpg|jpeg|png|webp)", value, re.IGNORECASE)):
            raise ValueError("Use an approved package image or a private product image uploaded through this portal.")
        return value


class ModelAutomationCommand(BaseModel):
    action: Literal["dispatch", "retry_failed", "train_now", "refresh_metrics"] = "dispatch"


class CatalogueChangeRequest(BaseModel):
    product: CatalogueProductInput
    crops: list[str] = Field(default_factory=list, max_length=100)

    @field_validator("crops")
    @classmethod
    def unique_crops(cls, values: list[str]) -> list[str]:
        cleaned = [value.strip()[:160] for value in values if value.strip()]
        if len(set(name.casefold() for name in cleaned)) != len(cleaned):
            raise ValueError("A crop can be included only once.")
        return cleaned


class DirectProductStatusChange(BaseModel):
    status: Literal["active", "inactive"]
    reason: str = Field(default="", max_length=500)


class ApprovalDecision(BaseModel):
    decision: Literal["approved", "rejected", "send_to_final_publisher"]
    note: str = Field(default="", max_length=2000)


class EmployeeRoleAssignment(BaseModel):
    roles: list[str] = Field(default_factory=list, max_length=len(ASSIGNABLE_ROLE_CODES))

    @field_validator("roles")
    @classmethod
    def known_unique_roles(cls, values: list[str]) -> list[str]:
        cleaned = [value.strip() for value in values if value.strip()]
        if len(set(cleaned)) != len(cleaned):
            raise ValueError("Each role can be selected only once.")
        unknown = sorted(set(cleaned) - ASSIGNABLE_ROLE_CODES)
        if unknown:
            raise ValueError(f"Unknown or protected roles: {', '.join(unknown)}")
        return cleaned


class PortalInvitation(EmployeeRoleAssignment):
    pass


class PortalPasswordLogin(BaseModel):
    email: str = Field(min_length=5, max_length=254)
    password: str = Field(min_length=8, max_length=200)


def _password_hash(password: str) -> str:
    salt = secrets.token_bytes(16)
    derived = hashlib.scrypt(password.encode(), salt=salt, n=16384, r=8, p=1, dklen=32)
    return "scrypt$16384$8$1$%s$%s" % (
        base64.urlsafe_b64encode(salt).decode().rstrip("="),
        base64.urlsafe_b64encode(derived).decode().rstrip("="),
    )


def _password_matches(password: str, encoded: str) -> bool:
    try:
        scheme, n, r, p, salt_text, expected_text = encoded.split("$")
        if scheme != "scrypt" or (n, r, p) != ("16384", "8", "1"):
            return False
        salt = base64.urlsafe_b64decode(salt_text + "=" * (-len(salt_text) % 4))
        expected = base64.urlsafe_b64decode(expected_text + "=" * (-len(expected_text) % 4))
        actual = hashlib.scrypt(password.encode(), salt=salt, n=16384, r=8, p=1, dklen=len(expected))
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


def _send_portal_invitation(email: str, name: str, temporary_password: str, roles: list[str]) -> tuple[bool, str]:
    if not SMTP_HOST or not PORTAL_INVITE_EMAIL_FROM:
        return False, "Company email delivery is not configured on the server."
    message = EmailMessage()
    message["From"] = PORTAL_INVITE_EMAIL_FROM
    message["To"] = email
    message["Subject"] = "Your Crop Life AI administration access"
    role_names = ", ".join(role.replace("_", " ") for role in roles) or "read-only employee access"
    message.set_content(
        f"Hello {name},\n\n"
        "You have been invited to the Crop Life AI operations portal.\n\n"
        f"Portal: {PORTAL_INVITE_URL}\n"
        f"Email: {email}\n"
        f"Temporary password: {temporary_password}\n"
        f"Assigned access: {role_names}\n\n"
        "Keep this password private. Contact the Crop Life AI administrator if you did not expect this invitation.\n"
    )
    try:
        if SMTP_PORT == 465:
            client = smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=10)
        else:
            client = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=10)
        with client:
            if SMTP_USE_TLS and SMTP_PORT != 465:
                client.starttls()
            if SMTP_USERNAME:
                client.login(SMTP_USERNAME, SMTP_PASSWORD)
            client.send_message(message)
        return True, "Invitation email sent."
    except (OSError, smtplib.SMTPException) as error:
        return False, f"Email delivery failed: {type(error).__name__}."


@router.post("/auth/password")
def portal_password_login(
    payload: PortalPasswordLogin,
    x_clsl_admin_gateway_token: Annotated[str | None, Header()] = None,
):
    """Validate an official employee invitation for the trusted Next.js BFF."""
    if not ADMIN_GATEWAY_TOKEN or not x_clsl_admin_gateway_token or not hmac.compare_digest(x_clsl_admin_gateway_token, ADMIN_GATEWAY_TOKEN):
        raise HTTPException(status_code=401, detail="Administration gateway authentication failed.")
    email = payload.email.strip().lower()
    with connection() as conn:
        account = conn.execute(
            """
            SELECT account.employee_id, account.password_hash, e.full_name,
                   COALESCE(e.office_email, e.microsoft_upn) AS email
            FROM portal_password_accounts account
            JOIN employees e ON e.id=account.employee_id
            WHERE lower(account.email)=%s AND account.active AND e.status='active'
            LIMIT 1
            """,
            (email,),
        ).fetchone()
        if not account or not _password_matches(payload.password, account["password_hash"]):
            raise HTTPException(status_code=401, detail="The email or password is incorrect.")
        conn.execute("UPDATE portal_password_accounts SET last_login_at=now() WHERE employee_id=%s", (account["employee_id"],))
        conn.commit()
    return {"email": account["email"], "name": account["full_name"]}


def _identity(
    x_clsl_admin_email: Annotated[str | None, Header()] = None,
    x_clsl_admin_gateway_token: Annotated[str | None, Header()] = None,
) -> AdminIdentity:
    if not ADMIN_GATEWAY_TOKEN:
        raise HTTPException(status_code=503, detail="The administration gateway is not configured.")
    if not x_clsl_admin_gateway_token or not hmac.compare_digest(x_clsl_admin_gateway_token, ADMIN_GATEWAY_TOKEN):
        raise HTTPException(status_code=401, detail="Administration gateway authentication failed.")
    email = (x_clsl_admin_email or "").strip().lower()
    if not email or (ADMIN_ALLOWED_EMAIL_DOMAIN and not email.endswith(f"@{ADMIN_ALLOWED_EMAIL_DOMAIN}")):
        raise HTTPException(status_code=403, detail="Use an approved Crop Life Microsoft account.")

    with connection() as conn:
        employee = conn.execute(
            """
            SELECT id, employee_code, full_name, COALESCE(office_email, microsoft_upn) AS email
            FROM employees
            WHERE status = 'active'
              AND (lower(office_email) = %s OR lower(microsoft_upn) = %s)
            LIMIT 1
            """,
            (email, email),
        ).fetchone()
        if employee:
            roles = conn.execute(
                "SELECT role_code FROM employee_roles WHERE employee_id = %s ORDER BY role_code",
                (employee["id"],),
            ).fetchall()
            identity = AdminIdentity(
                id=employee["id"], employee_code=employee["employee_code"],
                full_name=employee["full_name"], email=employee["email"],
                roles=[row["role_code"] for row in roles],
            )
        else:
            portal_identity = conn.execute(
                "SELECT id, employee_code, full_name, email, roles FROM portal_test_identities WHERE lower(email)=%s AND active",
                (email,),
            ).fetchone()
            if not portal_identity:
                raise HTTPException(status_code=403, detail="This Microsoft account is not an active Crop Life employee.")
            identity = AdminIdentity(**portal_identity, is_test_identity=True)
    return identity


def _can(identity: AdminIdentity, roles: set[str]) -> bool:
    return "super_admin" in identity.roles or bool(set(identity.roles) & roles)


def _require(identity: AdminIdentity, roles: set[str]) -> AdminIdentity:
    if not _can(identity, roles):
        raise HTTPException(status_code=403, detail="Your assigned role does not permit this action.")
    return identity


def _employee_actor_id(identity: AdminIdentity) -> UUID | None:
    return None if identity.is_test_identity else identity.id


def _portal_actor_id(identity: AdminIdentity) -> UUID | None:
    return identity.id if identity.is_test_identity else None


def _audit(conn, identity: AdminIdentity, action: str, entity_type: str, entity_key: str, previous: Any, new: Any):
    conn.execute(
        """
        INSERT INTO audit_logs(id, actor_employee_id, actor_portal_identity_id, action, entity_type, entity_key, previous_data, new_data)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """,
        (uuid4(), _employee_actor_id(identity), _portal_actor_id(identity), action, entity_type, entity_key,
         Jsonb(jsonable_encoder(previous)) if previous is not None else None,
         Jsonb(jsonable_encoder(new)) if new is not None else None),
    )


def _product_rows(conn):
    return conn.execute(
        """
        SELECT p.id, p.name, pc.name AS category, p.common_name, p.formulation, p.dose,
               p.use_benefits, p.packing, p.price_per_pack, p.application_method, p.safety_information,
               p.image_path, p.source_page, p.catalogue_version, p.status, p.approval_status,
               p.version, p.updated_at,
               COALESCE(array_agg(DISTINCT c.name) FILTER (WHERE c.id IS NOT NULL), '{}') AS crops,
               COALESCE(array_agg(DISTINCT pr.name) FILTER (WHERE pr.id IS NOT NULL), '{}') AS problems
        FROM products p
        JOIN product_categories pc ON pc.id = p.category_id
        LEFT JOIN product_crop_mappings pcm ON pcm.product_id = p.id AND pcm.approval_status = 'approved'
        LEFT JOIN crops c ON c.id = pcm.crop_id AND c.status = 'active'
        LEFT JOIN product_problem_mappings ppm ON ppm.product_id = p.id AND ppm.approval_status = 'approved'
        LEFT JOIN problems pr ON pr.id = ppm.problem_id AND pr.status = 'active'
        GROUP BY p.id, pc.name
        ORDER BY p.name
        """
    ).fetchall()


@router.get("/me")
def current_admin(identity: AdminIdentity = Depends(_identity)):
    _require(identity, ADMIN_READ_ROLES)
    return {
        "employee": identity.model_dump(mode="json"),
    "capabilities": {
            "view_overview": True,
            "view_catalogue": _can(identity, CATALOGUE_READ_ROLES),
            "submit_catalogue_changes": _can(identity, CATALOGUE_MANAGER_ROLES),
            "direct_catalogue_status": _can(identity, {"super_admin"}),
            "decide_crop_mappings": _can(identity, MAPPING_PUBLISHER_ROLES),
            "review_catalogue_changes": _can(identity, SENIOR_CATALOGUE_MANAGER_ROLES),
            "send_catalogue_changes_to_final_publisher": _can(identity, SENIOR_CATALOGUE_MANAGER_ROLES),
            "finalise_catalogue_release": _can(identity, FINAL_CATALOGUE_PUBLISHER_ROLES),
            "view_inspections": _can(identity, INSPECTION_REVIEW_ROLES),
            "delete_inspections": _can(identity, INSPECTION_DELETE_ROLES),
            "view_sales_officer_activity": _can(identity, SALES_ACTIVITY_ROLES),
            "view_model_observability": _can(identity, INSPECTION_REVIEW_ROLES),
            "control_model_pipeline": _can(identity, MODEL_PIPELINE_CONTROL_ROLES),
            "view_employee_access": _can(identity, {"employee_access_approver"}),
            "manage_employee_roles": _can(identity, {"super_admin"}),
            "view_dealers": _can(identity, SALES_ACTIVITY_ROLES),
            "manage_dealers": _can(identity, DEALER_WRITE_ROLES),
            "manage_dealer_portal_mobile": _can(identity, {"super_admin"}),
            "archive_dealers": _can(identity, DEALER_ARCHIVE_ROLES),
        },
    }


@router.get("/overview")
def overview(identity: AdminIdentity = Depends(_identity)):
    _require(identity, ADMIN_READ_ROLES)
    with connection() as conn:
        products = conn.execute(
            """
            SELECT count(*) FILTER (WHERE status = 'active' AND approval_status = 'approved') AS approved,
                   count(*) FILTER (WHERE status = 'inactive' AND approval_status = 'approved') AS inactive,
                   count(*) FILTER (WHERE approval_status = 'pending') AS pending,
                   count(*) FILTER (WHERE status = 'draft') AS draft
            FROM products
            """
        ).fetchone()
        approvals = conn.execute("SELECT count(*) AS pending FROM approval_requests WHERE status = 'pending'").fetchone()
        inspections = conn.execute(
            """
            SELECT count(*) AS total,
                   count(*) FILTER (WHERE status = 'completed') AS completed,
                   count(*) FILTER (WHERE status = 'failed') AS failed,
                   count(*) FILTER (WHERE image_storage_status = 'stored') AS s3_stored,
                   count(*) FILTER (WHERE image_storage_status IN ('failed', 'partial_failure')) AS storage_attention
            FROM inspections WHERE created_at >= now() - interval '30 days'
            """
        ).fetchone()
        images = conn.execute(
            """
            SELECT count(*) FILTER (WHERE storage_provider = 's3' AND retention_status = 'retained') AS retained_files,
                   COALESCE(sum(byte_size) FILTER (WHERE storage_provider = 's3' AND retention_status = 'retained'), 0) AS retained_bytes
            FROM inspection_images
            """
        ).fetchone()
    return {"products": products, "approvals": approvals, "inspections_30d": inspections, "private_s3": images}


@router.get("/catalogue/products")
def catalogue_products(identity: AdminIdentity = Depends(_identity)):
    _require(identity, CATALOGUE_READ_ROLES)
    with connection() as conn:
        return {"items": _product_rows(conn)}


@router.patch("/catalogue/products/{product_id}/status")
def set_catalogue_product_status(
    product_id: str,
    payload: DirectProductStatusChange,
    identity: AdminIdentity = Depends(_identity),
):
    """Allow only the protected Super Administrator to change availability now."""
    _require(identity, {"super_admin"})
    with connection() as conn:
        product = conn.execute(
            "SELECT id, name, status, approval_status, version FROM products WHERE id = %s FOR UPDATE",
            (product_id,),
        ).fetchone()
        if not product:
            raise HTTPException(status_code=404, detail="Product not found.")
        if product["approval_status"] != "approved":
            raise HTTPException(status_code=409, detail="Only a finally approved product can be activated or deactivated directly.")
        if product["status"] == payload.status:
            return {"id": product_id, "name": product["name"], "status": payload.status, "changed": False}
        conn.execute(
            "UPDATE products SET status = %s, version = version + 1, updated_at = now() WHERE id = %s",
            (payload.status, product_id),
        )
        _audit(
            conn, identity, "direct_product_status_change", "product_catalogue", product_id,
            {"status": product["status"], "version": product["version"]},
            {"status": payload.status, "reason": payload.reason.strip() or "Super Administrator direct availability control"},
        )
        conn.commit()
    return {"id": product_id, "name": product["name"], "status": payload.status, "changed": True}


@router.get("/catalogue/options")
def catalogue_options(identity: AdminIdentity = Depends(_identity)):
    _require(identity, CATALOGUE_READ_ROLES)
    with connection() as conn:
        categories = conn.execute("SELECT name FROM product_categories ORDER BY name").fetchall()
        crops = conn.execute("SELECT name FROM crops WHERE status = 'active' ORDER BY name").fetchall()
    return {"categories": [row["name"] for row in categories], "crops": [row["name"] for row in crops]}


@router.post("/catalogue/change-requests", status_code=201)
def submit_catalogue_change(payload: CatalogueChangeRequest, identity: AdminIdentity = Depends(_identity)):
    _require(identity, CATALOGUE_MANAGER_ROLES)
    product = payload.product.model_dump()
    with connection() as conn:
        category = conn.execute("SELECT id FROM product_categories WHERE name = %s", (product["category"],)).fetchone()
        if not category:
            raise HTTPException(status_code=422, detail="Select a valid product category.")
        crop_rows = conn.execute("SELECT name FROM crops WHERE status = 'active' AND name = ANY(%s)", (payload.crops,)).fetchall()
        found_crops = {row["name"] for row in crop_rows}
        missing_crops = [crop for crop in payload.crops if crop not in found_crops]
        if missing_crops:
            raise HTTPException(status_code=422, detail=f"Unknown or inactive crops: {', '.join(missing_crops)}")
        existing = conn.execute("SELECT id, name FROM products WHERE id = %s", (product["product_id"],)).fetchone()
        action = "update_product_catalogue" if existing else "create_product_catalogue"
        duplicate = conn.execute("SELECT id FROM products WHERE name = %s AND id <> %s", (product["name"], product["product_id"])).fetchone()
        if duplicate:
            raise HTTPException(status_code=409, detail="Another product already uses this product name.")
        proposed = {"product": product, "crops": payload.crops}
        request_id = uuid4()
        conn.execute(
            """
            INSERT INTO approval_requests(
                id, entity_type, entity_key, requested_action, proposed_data, status,
                review_stage, requested_by, requested_by_portal_identity
            )
            VALUES (%s, 'product_catalogue', %s, %s, %s, 'pending', 'senior_manager', %s, %s)
            """,
            (request_id, product["product_id"], action, Jsonb(proposed),
             _employee_actor_id(identity), _portal_actor_id(identity)),
        )
        _audit(conn, identity, "submit_catalogue_change", "approval_request", str(request_id), None, proposed)
        conn.commit()
    return {"id": str(request_id), "status": "pending", "message": "Catalogue change submitted for approval."}


@router.get("/approvals")
def approval_requests(
    status: Literal["pending", "approved", "rejected"] = Query(default="pending"),
    identity: AdminIdentity = Depends(_identity),
):
    _require(identity, CATALOGUE_READ_ROLES)
    with connection() as conn:
        rows = conn.execute(
            """
            SELECT ar.id, ar.entity_key, ar.requested_action, ar.proposed_data, ar.status, ar.review_stage,
                   ar.decision_note, ar.requested_at, ar.decided_at,
                   COALESCE(requestor.full_name, portal_requestor.full_name) AS requested_by_name,
                   COALESCE(requestor.office_email, portal_requestor.email) AS requested_by_email,
                   COALESCE(decider.full_name, portal_decider.full_name) AS decided_by_name
            FROM approval_requests ar
            LEFT JOIN employees requestor ON requestor.id = ar.requested_by
            LEFT JOIN portal_test_identities portal_requestor ON portal_requestor.id = ar.requested_by_portal_identity
            LEFT JOIN employees decider ON decider.id = ar.decided_by
            LEFT JOIN portal_test_identities portal_decider ON portal_decider.id = ar.decided_by_portal_identity
            WHERE ar.entity_type = 'product_catalogue' AND ar.status = %s
            ORDER BY ar.requested_at DESC
            LIMIT 200
            """,
            (status,),
        ).fetchall()
    return {"items": rows}


@router.post("/approvals/{request_id}/decision")
def decide_catalogue_change(request_id: UUID, decision: ApprovalDecision, identity: AdminIdentity = Depends(_identity)):
    with connection() as conn:
        request = conn.execute(
            """
            SELECT * FROM approval_requests
            WHERE id = %s AND entity_type = 'product_catalogue' AND status = 'pending'
            FOR UPDATE
            """,
            (request_id,),
        ).fetchone()
        if not request:
            raise HTTPException(status_code=404, detail="Pending catalogue approval request not found.")

        review_stage = request["review_stage"] or "senior_manager"
        # Stage 1: senior catalogue review. A senior reviewer may reject an
        # unsafe/incomplete proposal or validate it and put it into the final
        # release queue. This stage never changes live farmer advice.
        if decision.decision == "send_to_final_publisher":
            _require(identity, SENIOR_CATALOGUE_MANAGER_ROLES)
            if review_stage != "senior_manager":
                raise HTTPException(status_code=409, detail="This request is already in the final release queue or has been decided.")
            note = decision.note.strip() or None
            conn.execute(
                "UPDATE approval_requests SET review_stage = 'final_publisher', decision_note = %s WHERE id = %s",
                (note, request_id),
            )
            _audit(conn, identity, "send_catalogue_change_to_final_release", "approval_request", str(request_id), {"review_stage": review_stage}, {"review_stage": "final_publisher", "note": note})
            conn.commit()
            return {"id": str(request_id), "status": "pending", "review_stage": "final_publisher"}

        # Final approval is deliberately separated from the senior review.
        # It writes directly to PostgreSQL, so the inspection engine, chatbot
        # and live product browser see the updated catalogue immediately.
        if review_stage == "final_publisher":
            _require(identity, FINAL_CATALOGUE_PUBLISHER_ROLES)
        elif review_stage == "senior_manager":
            _require(identity, SENIOR_CATALOGUE_MANAGER_ROLES)
            if decision.decision == "approved":
                raise HTTPException(status_code=409, detail="Senior review is complete only after sending the request to the final release queue.")
        else:
            raise HTTPException(status_code=409, detail="This approval has an unsupported review stage.")

        same_requestor = (
            (not identity.is_test_identity and request["requested_by"] == identity.id)
            or (identity.is_test_identity and request["requested_by_portal_identity"] == identity.id)
        )
        if same_requestor and review_stage == "senior_manager":
            raise HTTPException(status_code=403, detail="A separate Senior Catalogue Manager must review your own change.")

        proposed = request["proposed_data"]
        product: dict[str, Any] = proposed["product"]
        requested_crops: list[str] = proposed.get("crops", [])
        existing_crops = conn.execute(
            """
            SELECT c.name FROM product_crop_mappings pcm JOIN crops c ON c.id = pcm.crop_id
            WHERE pcm.product_id = %s AND pcm.approval_status = 'approved'
            """,
            (product["product_id"],),
        ).fetchall()
        has_mapping_change = {row["name"] for row in existing_crops} != set(requested_crops)
        if has_mapping_change and not _can(identity, MAPPING_PUBLISHER_ROLES):
            raise HTTPException(status_code=403, detail="This request changes crop mappings and also requires Mapping Approver authority.")

        if decision.decision == "rejected":
            conn.execute(
                """UPDATE approval_requests SET status = 'rejected', decided_by = %s,
                   decided_by_portal_identity = %s, decision_note = %s, decided_at = now() WHERE id = %s""",
                (_employee_actor_id(identity), _portal_actor_id(identity), decision.note.strip() or None, request_id),
            )
            _audit(conn, identity, "reject_catalogue_change", "approval_request", str(request_id), proposed, {"note": decision.note.strip()})
            conn.commit()
            return {"id": str(request_id), "status": "rejected"}

        category = conn.execute("SELECT id FROM product_categories WHERE name = %s", (product["category"],)).fetchone()
        crop_rows = conn.execute("SELECT id, name FROM crops WHERE status = 'active' AND name = ANY(%s)", (requested_crops,)).fetchall()
        if not category or len(crop_rows) != len(requested_crops):
            raise HTTPException(status_code=409, detail="Category or crop master data changed. Submit the change again.")
        previous = conn.execute("SELECT * FROM products WHERE id = %s", (product["product_id"],)).fetchone()

        values = (
            product["product_id"], product["name"], category["id"], product["common_name"] or None,
            product["formulation"] or None, product["dose"] or None, product["use_benefits"] or None,
            product["packing"] or None, product["price_per_pack"], product["application_method"] or None,
            product["safety_information"] or None, product["image_path"] or None,
            product["source_page"], product["catalogue_version"] or "Admin catalogue", product["status"], _employee_actor_id(identity),
        )
        if previous:
            conn.execute(
                """
                UPDATE products SET name=%s, category_id=%s, common_name=%s, formulation=%s, dose=%s,
                    use_benefits=%s, packing=%s, price_per_pack=%s, application_method=%s, safety_information=%s,
                    image_path=%s, source_page=%s, catalogue_version=%s, status=%s,
                    approval_status='approved', approved_by=%s, approved_at=now(), version=version+1, updated_at=now()
                WHERE id=%s
                """,
                values[1:] + (product["product_id"],),
            )
        else:
            conn.execute(
                """
                INSERT INTO products(id, name, category_id, common_name, formulation, dose, use_benefits,
                    packing, price_per_pack, application_method, safety_information, image_path, source_page,
                    catalogue_version, status, approval_status, approved_by, approved_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                        %s, 'approved', %s, now())
                """,
                values,
            )

        if has_mapping_change or not previous:
            conn.execute("DELETE FROM product_crop_mappings WHERE product_id = %s", (product["product_id"],))
            for crop in crop_rows:
                conn.execute(
                    """
                    INSERT INTO product_crop_mappings(product_id, crop_id, approval_status, submitted_by, approved_by, approved_at)
                    VALUES (%s, %s, 'approved', %s, %s, now())
                    """,
                    (product["product_id"], crop["id"], request["requested_by"], _employee_actor_id(identity)),
                )
        conn.execute(
            """UPDATE approval_requests SET status = 'approved', decided_by = %s,
               decided_by_portal_identity = %s, decision_note = %s, decided_at = now() WHERE id = %s""",
            (_employee_actor_id(identity), _portal_actor_id(identity), decision.note.strip() or None, request_id),
        )
        _audit(conn, identity, "approve_catalogue_change", "product_catalogue", product["product_id"], previous, proposed)
        conn.commit()
    return {"id": str(request_id), "status": "approved", "product_id": product["product_id"]}


@router.get("/inspections")
def inspection_activity(identity: AdminIdentity = Depends(_identity)):
    _require(identity, INSPECTION_REVIEW_ROLES)
    with connection() as conn:
        rows = conn.execute(
            """
            SELECT i.id, i.created_at, i.status, i.farmer_crop_text, i.declared_crop_text,
                   i.crop_source, i.diagnosis_confidence, i.ai_needs_more_information,
                   i.dataset_quality_status, i.training_eligible, i.location_text, i.photo_count,
                   i.collection_mode, i.photo_requirements_met, i.photo_guidance_version,
                   employee.full_name AS employee_name, employee.employee_code,
                   i.image_storage_status, i.image_storage_failures, i.failure_message,
                   count(DISTINCT ii.id) FILTER (WHERE ii.retention_status = 'retained') AS retained_images,
                   (SELECT COALESCE(sum(img.byte_size), 0) FROM inspection_images img WHERE img.inspection_id=i.id AND img.retention_status='retained') AS retained_bytes,
                   COALESCE(array_agg(DISTINCT ii.image_order) FILTER (WHERE ii.retention_status = 'retained' AND ii.storage_provider = 's3'), '{}') AS image_orders,
                   COALESCE(jsonb_agg(DISTINCT apr.provider) FILTER (WHERE apr.provider IS NOT NULL), '[]'::jsonb) AS providers,
                   COALESCE(jsonb_agg(DISTINCT ir.product_id) FILTER (WHERE ir.product_id IS NOT NULL), '[]'::jsonb) AS suggested_product_ids,
                   prediction.crop_text AS detected_crop, prediction.issue_name AS probable_issue,
                   prediction.issue_type AS issue_type, prediction.severity AS severity,
                   prediction.confidence AS confidence, prediction.summary AS summary,
                   prediction.recommended_next_action AS recommended_next_action,
                   consensus.consensus_status, consensus.agreement_count,
                   consensus.successful_models, consensus.consensus_issue_name,
                   predictions.model_predictions
            FROM inspections i
            LEFT JOIN employees employee ON employee.id=i.employee_id
            LEFT JOIN inspection_images ii ON ii.inspection_id = i.id
            LEFT JOIN ai_provider_results apr ON apr.inspection_id = i.id
            LEFT JOIN inspection_recommendations ir ON ir.inspection_id = i.id
            LEFT JOIN LATERAL (
                SELECT crop_text, issue_name, issue_type, severity, confidence, summary, recommended_next_action
                FROM ai_predictions prediction
                WHERE prediction.inspection_id = i.id AND prediction.provider IN ('gemma','gemini')
                ORDER BY CASE prediction.prediction_role WHEN 'primary' THEN 0 ELSE 1 END, prediction.created_at DESC
                LIMIT 1
            ) prediction ON true
            LEFT JOIN inspection_model_consensus consensus ON consensus.inspection_id=i.id
            LEFT JOIN LATERAL (
                SELECT jsonb_agg(jsonb_build_object(
                    'provider', p.provider, 'model', p.model_name, 'role', p.prediction_role,
                    'crop', p.crop_text, 'issue_type', p.issue_type, 'issue_name', p.issue_name,
                    'severity', p.severity, 'confidence', p.confidence,
                    'needs_more_information', p.additional_information_required,
                    'latency_ms', p.latency_ms, 'summary', p.summary
                ) ORDER BY CASE p.provider WHEN 'gemma' THEN 0 WHEN 'gemini' THEN 1 ELSE 2 END) AS model_predictions
                FROM ai_predictions p WHERE p.inspection_id=i.id
                  AND p.provider IN ('gemma','gemini','qwen')
            ) predictions ON true
            GROUP BY i.id, employee.id, prediction.crop_text, prediction.issue_name, prediction.issue_type,
                     prediction.severity, prediction.confidence, prediction.summary, prediction.recommended_next_action,
                     consensus.inspection_id, predictions.model_predictions
            ORDER BY i.created_at DESC
            """
        ).fetchall()
    return {"items": rows}


@router.get("/inspections/{inspection_id}/images/{image_order}")
def inspection_image_metadata(inspection_id: UUID, image_order: int, identity: AdminIdentity = Depends(_identity)):
    _require(identity, INSPECTION_REVIEW_ROLES)
    if image_order < 1 or image_order > 5:
        raise HTTPException(status_code=404, detail="Retained inspection image not found.")
    with connection() as conn:
        image = conn.execute(
            """
            SELECT storage_bucket, storage_key, content_type, byte_size, image_order
            FROM inspection_images
            WHERE inspection_id = %s AND image_order = %s AND storage_provider = 's3'
              AND retention_status = 'retained'
            LIMIT 1
            """,
            (inspection_id, image_order),
        ).fetchone()
    if not image or not image["storage_bucket"] or not image["storage_key"]:
        raise HTTPException(status_code=404, detail="Retained inspection image not found.")
    return {"bucket": image["storage_bucket"], "key": image["storage_key"], "mime_type": image["content_type"], "byte_size": image["byte_size"], "image_order": image["image_order"]}


@router.get('/images')
def inspection_image_gallery(offset: int = Query(default=0, ge=0), limit: int = Query(default=25, ge=0, le=5000), identity: AdminIdentity = Depends(_identity)):
    _require(identity, INSPECTION_REVIEW_ROLES)
    with connection() as conn:
        total = conn.execute("SELECT count(*) AS total FROM inspection_images WHERE storage_provider='s3' AND retention_status='retained'").fetchone()['total']
        query = """SELECT ii.inspection_id, ii.image_order, ii.byte_size, ii.capture_role,
            i.created_at, i.farmer_crop_text, i.location_text, i.collection_mode, i.photo_requirements_met,
            e.full_name AS employee_name FROM inspection_images ii JOIN inspections i ON i.id=ii.inspection_id
            LEFT JOIN employees e ON e.id=i.employee_id WHERE ii.storage_provider='s3' AND ii.retention_status='retained'
            ORDER BY i.created_at DESC, ii.inspection_id, ii.image_order"""
        rows = conn.execute(query if limit == 0 else query + " LIMIT %s OFFSET %s", () if limit == 0 else (limit, offset)).fetchall()
    return {'items': rows, 'total': total, 'offset': offset, 'limit': limit}


@router.get("/inspections/{inspection_id}/deletion")
def inspection_deletion_metadata(inspection_id: UUID, identity: AdminIdentity = Depends(_identity)):
    """Return exact private objects before an authorised quality deletion."""
    _require(identity, INSPECTION_DELETE_ROLES)
    with connection() as conn:
        inspection = conn.execute("SELECT id FROM inspections WHERE id = %s", (inspection_id,)).fetchone()
        if not inspection:
            raise HTTPException(status_code=404, detail="Inspection not found.")
        images = conn.execute(
            """
            SELECT storage_bucket, storage_key, content_type, byte_size, image_order
            FROM inspection_images
            WHERE inspection_id = %s AND storage_provider = 's3' AND retention_status = 'retained'
            ORDER BY image_order
            """,
            (inspection_id,),
        ).fetchall()
    return {"inspection_id": str(inspection_id), "images": [
        {"bucket": image["storage_bucket"], "key": image["storage_key"]} for image in images
    ]}


@router.delete("/inspections/{inspection_id}")
def delete_inspection(inspection_id: UUID, identity: AdminIdentity = Depends(_identity)):
    """Delete persisted inspection metadata after the BFF has removed S3 evidence."""
    _require(identity, INSPECTION_DELETE_ROLES)
    with connection() as conn:
        existing = conn.execute("SELECT id, status, photo_count FROM inspections WHERE id = %s FOR UPDATE", (inspection_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Inspection not found.")
        # All dependent tables use ON DELETE CASCADE or SET NULL. S3 objects are
        # deliberately removed first by the authenticated Node BFF, not by the DB.
        conn.execute("DELETE FROM inspections WHERE id = %s", (inspection_id,))
        _audit(conn, identity, "delete_inspection", "inspection", str(inspection_id),
               {"id": str(existing["id"]), "status": existing["status"], "photo_count": existing["photo_count"]},
               {"s3_evidence_deleted": True})
        conn.commit()
    return {"id": str(inspection_id), "deleted": True}


@router.get("/sales-officers")
def sales_officer_activity(
    day: str = Query(default="", pattern=r"^$|^\d{4}-\d{2}-\d{2}$"),
    state: str = Query(default="", max_length=120),
    territory: str = Query(default="", max_length=160),
    identity: AdminIdentity = Depends(_identity),
):
    """Roster plus attributable inspection counts for the selected India day.

    The selected officer is attached only when an inspection contains a real
    employee_id. Existing anonymous farmer inspections are reported separately
    and never guessed onto an employee record.
    """
    _require(identity, SALES_ACTIVITY_ROLES)
    try:
        selected_day = date.fromisoformat(day) if day else datetime.now(ZoneInfo('Asia/Kolkata')).date()
    except ValueError:
        raise HTTPException(status_code=422, detail="Choose a valid calendar date.")
    with connection() as conn:
        rows = conn.execute(
            """
            WITH selected AS (
                SELECT COALESCE(%s::date, (now() AT TIME ZONE 'Asia/Kolkata')::date) AS report_day
            ), activity AS (
                SELECT i.employee_id,
                       count(*) FILTER (WHERE (i.created_at AT TIME ZONE 'Asia/Kolkata')::date = selected.report_day) AS day_uploads,
                       COALESCE(sum(i.photo_count) FILTER (WHERE (i.created_at AT TIME ZONE 'Asia/Kolkata')::date = selected.report_day), 0) AS day_images,
                       count(*) FILTER (WHERE (i.created_at AT TIME ZONE 'Asia/Kolkata')::date = selected.report_day AND i.photo_count >= 4 AND i.photo_requirements_met) AS day_complete_sets,
                       count(DISTINCT COALESCE(c.name, NULLIF(i.farmer_crop_text, ''))) FILTER (WHERE (i.created_at AT TIME ZONE 'Asia/Kolkata')::date = selected.report_day) AS day_distinct_crops,
                       count(DISTINCT prediction.issue_name) FILTER (WHERE (i.created_at AT TIME ZONE 'Asia/Kolkata')::date = selected.report_day) AS day_distinct_problems,
                       count(DISTINCT i.id) FILTER (WHERE (i.created_at AT TIME ZONE 'Asia/Kolkata')::date = selected.report_day AND candidate.candidate_status IN ('eligible','exported','training','used')) AS day_quality_eligible,
                       count(DISTINCT i.id) FILTER (WHERE (i.created_at AT TIME ZONE 'Asia/Kolkata')::date = selected.report_day AND candidate.label_tier = 'gemini_flash_lite_fallback') AS day_gemini_fallback,
                       count(*) FILTER (WHERE (i.created_at AT TIME ZONE 'Asia/Kolkata')::date BETWEEN selected.report_day - 29 AND selected.report_day) AS month_uploads,
                       COALESCE(sum(i.photo_count) FILTER (WHERE (i.created_at AT TIME ZONE 'Asia/Kolkata')::date BETWEEN selected.report_day - 29 AND selected.report_day), 0) AS month_images,
                       count(*) FILTER (WHERE (i.created_at AT TIME ZONE 'Asia/Kolkata')::date BETWEEN selected.report_day - 29 AND selected.report_day AND i.photo_count >= 4 AND i.photo_requirements_met) AS month_complete_sets,
                       count(DISTINCT (i.created_at AT TIME ZONE 'Asia/Kolkata')::date) FILTER (WHERE (i.created_at AT TIME ZONE 'Asia/Kolkata')::date BETWEEN selected.report_day - 29 AND selected.report_day AND i.photo_count >= 4 AND i.photo_requirements_met) AS active_days_30,
                       max(i.created_at) AS last_upload_at
                FROM inspections i CROSS JOIN selected
                LEFT JOIN crops c ON c.id=i.crop_id
                LEFT JOIN LATERAL (SELECT issue_name FROM ai_predictions p WHERE p.inspection_id=i.id AND p.provider='gemini' ORDER BY p.created_at DESC LIMIT 1) prediction ON true
                LEFT JOIN auto_training_candidates candidate ON candidate.inspection_id=i.id
                GROUP BY i.employee_id
            )
            SELECT sot.id, sot.state, sot.territory,
                   e.id AS employee_id, e.employee_code, e.full_name, e.office_email,
                   e.office_mobile, e.personal_mobile, e.personal_email, e.department, e.designation, e.location,
                   e.reporting_manager_name, e.hr_sync_state, e.status AS employee_status,
                   COALESCE(a.day_uploads, 0) AS day_uploads,
                   COALESCE(a.day_images, 0) AS day_images,
                   COALESCE(a.day_complete_sets, 0) AS day_complete_sets,
                   COALESCE(a.day_distinct_crops, 0) AS day_distinct_crops,
                   COALESCE(a.day_distinct_problems, 0) AS day_distinct_problems,
                   COALESCE(a.day_quality_eligible, 0) AS day_quality_eligible,
                   COALESCE(a.day_gemini_fallback, 0) AS day_gemini_fallback,
                   COALESCE(a.month_uploads, 0) AS month_uploads,
                   COALESCE(a.month_images, 0) AS month_images,
                   COALESCE(a.month_complete_sets, 0) AS month_complete_sets,
                   COALESCE(a.active_days_30, 0) AS active_days_30,
                   a.last_upload_at,
                   (e.id IS NOT NULL) AS employee_matched,
                   (access_grant.id IS NOT NULL) AS has_access_link,
                   access_grant.created_at AS access_link_created_at,
                   access_grant.last_used_at AS access_link_last_used_at,
                   COALESCE((SELECT array_agg(er.role_code) FROM employee_roles er WHERE er.employee_id=e.id), '{}') AS roles
            FROM sales_officer_territories sot
            LEFT JOIN employees e ON e.id = sot.employee_id
            LEFT JOIN activity a ON a.employee_id = e.id
            LEFT JOIN LATERAL (
                SELECT grant_record.id, grant_record.created_at, grant_record.last_used_at
                FROM field_access_grants grant_record
                WHERE grant_record.employee_id=e.id AND grant_record.revoked_at IS NULL
                  AND (grant_record.expires_at IS NULL OR grant_record.expires_at > now())
                ORDER BY grant_record.created_at DESC LIMIT 1
            ) access_grant ON true
            WHERE (%s = '' OR sot.state = %s)
              AND (%s = '' OR sot.territory = %s)
            ORDER BY sot.state, sot.territory
            """,
            (selected_day, state, state, territory, territory),
        ).fetchall()
        anonymous = conn.execute(
            """
            SELECT count(*) AS day_uploads
            FROM inspections CROSS JOIN (SELECT COALESCE(%s::date, (now() AT TIME ZONE 'Asia/Kolkata')::date) AS report_day) selected
            WHERE employee_id IS NULL AND (created_at AT TIME ZONE 'Asia/Kolkata')::date = selected.report_day
            """,
            (selected_day,),
        ).fetchone()
    return {"items": rows, "report_day": selected_day, "anonymous_day_uploads": anonymous["day_uploads"]}


@router.post("/models/automation")
def control_model_automation(
    payload: ModelAutomationCommand,
    identity: AdminIdentity = Depends(_identity),
):
    """Synchronise the queue or start a metric-gated continuous-training cycle."""
    _require(identity, MODEL_PIPELINE_CONTROL_ROLES)
    result = run_pipeline_cycle(
        force_training=payload.action == "train_now",
        reset_failed=payload.action == "retry_failed",
    )
    with connection() as conn:
        _audit(
            conn, identity, f"model_automation_{payload.action}", "model_pipeline",
            "continuous_qwen_pipeline", None, result,
        )
        conn.commit()
    return result


@router.get("/models")
def automated_model_observability(identity: AdminIdentity = Depends(_identity)):
    """Three-model operations, majority labels and continuous-training telemetry."""
    _require(identity, INSPECTION_REVIEW_ROLES)
    with connection() as conn:
        providers = conn.execute(
            """
            SELECT result.provider,result.model_name,count(*) AS attempts,
                   count(*) FILTER (WHERE result.success) AS successful,
                   count(*) FILTER (WHERE NOT result.success) AS failed,
                   round(count(*) FILTER (WHERE result.success)::numeric*100/NULLIF(count(*),0),1) AS success_rate_percent,
                   round(avg(result.latency_ms) FILTER (WHERE result.success),1) AS average_latency_ms,
                   round(avg(prediction.confidence)*100,1) AS average_confidence_percent,
                   count(prediction.confidence) AS confidence_samples,max(result.created_at) AS latest_attempt
            FROM ai_provider_results result
            LEFT JOIN LATERAL (
                SELECT confidence FROM ai_predictions p
                WHERE p.inspection_id=result.inspection_id AND p.provider=result.provider
                ORDER BY p.created_at DESC LIMIT 1
            ) prediction ON true
            WHERE result.provider IN ('gemma','gemini','qwen')
            GROUP BY result.provider,result.model_name
            ORDER BY CASE result.provider WHEN 'gemma' THEN 0 WHEN 'gemini' THEN 1 ELSE 2 END,result.model_name
            """
        ).fetchall()
        queue = conn.execute(
            """
            SELECT count(*) AS total,
                   count(*) FILTER (WHERE status IN ('pending','retry','deferred')) AS waiting,
                   count(*) FILTER (WHERE status='processing') AS processing,
                   count(*) FILTER (WHERE status='completed') AS completed,
                   count(*) FILTER (WHERE status='failed') AS failed,
                   min(created_at) FILTER (WHERE status IN ('pending','retry','deferred')) AS oldest_waiting_at,
                   round(avg(latency_ms) FILTER (WHERE status='completed'),1) AS average_latency_ms,
                   max(completed_at) FILTER (WHERE status='completed') AS latest_completed_at
            FROM qwen_shadow_jobs
            """
        ).fetchone()
        runtime = conn.execute(
            "SELECT status,details,updated_at FROM ai_runtime_status WHERE status_key='qwen_worker'"
        ).fetchone()
        gemini_queue = conn.execute(
            """
            SELECT count(*) AS total,
                   count(*) FILTER (WHERE status IN ('pending','retry')) AS waiting,
                   count(*) FILTER (WHERE status='processing') AS processing,
                   count(*) FILTER (WHERE status='completed') AS completed,
                   count(*) FILTER (WHERE status='failed') AS failed,
                   min(created_at) FILTER (WHERE status IN ('pending','retry')) AS oldest_waiting_at,
                   round(avg(latency_ms) FILTER (WHERE status='completed'),1) AS average_latency_ms,
                   max(completed_at) FILTER (WHERE status='completed') AS latest_completed_at
            FROM gemini_shadow_jobs
            """
        ).fetchone()
        gemini_runtime = conn.execute(
            "SELECT status,details,updated_at FROM ai_runtime_status WHERE status_key='gemini_shadow_worker'"
        ).fetchone()
        pipeline = conn.execute(
            "SELECT * FROM model_pipeline_state WHERE state_key='continuous_qwen_pipeline'"
        ).fetchone()
        candidate_summary = conn.execute(
            """
            SELECT count(*) AS total,
                   count(*) FILTER (WHERE candidate_status='eligible') AS eligible,
                   count(*) FILTER (WHERE candidate_status='excluded') AS excluded,
                   count(*) FILTER (WHERE candidate_status='waiting_models') AS waiting_models,
                   count(*) FILTER (WHERE candidate_status IN ('exported','training')) AS in_training,
                   count(*) FILTER (WHERE candidate_status='used') AS used,
                   round(avg(quality_score) FILTER (WHERE candidate_status<>'excluded')*100,1) AS mean_quality_percent,
                   count(DISTINCT crop_text) FILTER (WHERE candidate_status<>'excluded') AS crop_classes,
                   count(DISTINCT issue_type) FILTER (WHERE candidate_status<>'excluded') AS issue_classes,
                   count(*) FILTER (WHERE label_tier='three_model_consensus') AS three_model_consensus,
                   count(*) FILTER (WHERE label_tier='two_model_consensus') AS two_model_consensus,
                   count(*) FILTER (WHERE label_tier='gemini_flash_lite_fallback') AS gemini_fallback
            FROM auto_training_candidates
            """
        ).fetchone()
        candidates = conn.execute(
            """
            SELECT candidate.inspection_id,candidate.candidate_status,candidate.crop_text,
                   candidate.issue_type,candidate.issue_name,candidate.severity,
                   candidate.label_source,candidate.gemma_model,candidate.gemini_model,candidate.qwen_model,
                   candidate.gemma_confidence,candidate.gemini_confidence,candidate.qwen_confidence,
                   candidate.majority_count,candidate.agreeing_providers,candidate.issue_name_similarity,
                   candidate.quality_score,candidate.label_tier,candidate.sample_weight,
                   candidate.image_count,candidate.exclusion_reason,
                   candidate.assigned_run_id,candidate.updated_at,
                   employee.full_name AS employee_name,employee.employee_code
            FROM auto_training_candidates candidate
            JOIN inspections inspection ON inspection.id=candidate.inspection_id
            LEFT JOIN employees employee ON employee.id=inspection.employee_id
            ORDER BY candidate.updated_at DESC LIMIT 100
            """
        ).fetchall()
        jobs = conn.execute(
            """
            SELECT job.id,job.inspection_id,job.status,job.attempt_count,job.max_attempts,
                    job.latency_ms,job.agreement_json,job.error_category,job.last_error,
                    job.created_at,job.started_at,job.completed_at,job.next_attempt_at,
                    gemini_job.status AS gemini_status,gemini_job.attempt_count AS gemini_attempt_count,
                    gemini_job.latency_ms AS gemini_latency_ms,gemini_job.last_error AS gemini_last_error,
                    COALESCE(inspection.declared_crop_text,inspection.farmer_crop_text) AS declared_crop,
                    employee.full_name AS employee_name,employee.employee_code,
                    gemma.model_name AS gemma_model,gemma.issue_type AS gemma_issue_type,
                    gemma.issue_name AS gemma_issue,gemma.confidence AS gemma_confidence,
                    gemini.model_name AS gemini_model,gemini.issue_type AS gemini_issue_type,
                    gemini.issue_name AS gemini_issue,gemini.confidence AS gemini_confidence,
                    qwen.model_name AS qwen_model,qwen.issue_type AS qwen_issue_type,
                    qwen.issue_name AS qwen_issue,qwen.confidence AS qwen_confidence,
                    consensus.consensus_status,consensus.consensus_issue_type,
                    consensus.consensus_issue_name,consensus.consensus_severity,
                    consensus.agreement_count
            FROM qwen_shadow_jobs job
            JOIN inspections inspection ON inspection.id=job.inspection_id
            LEFT JOIN employees employee ON employee.id=inspection.employee_id
            LEFT JOIN gemini_shadow_jobs gemini_job ON gemini_job.inspection_id=job.inspection_id
            LEFT JOIN LATERAL (
                SELECT model_name,issue_type,issue_name,confidence FROM ai_predictions
                WHERE inspection_id=job.inspection_id AND provider='gemma' ORDER BY created_at DESC LIMIT 1
            ) gemma ON true
            LEFT JOIN LATERAL (
                SELECT model_name,issue_type,issue_name,confidence FROM ai_predictions
                WHERE inspection_id=job.inspection_id AND provider='gemini' ORDER BY created_at DESC LIMIT 1
            ) gemini ON true
            LEFT JOIN LATERAL (
                SELECT model_name,issue_type,issue_name,confidence FROM ai_predictions
                WHERE inspection_id=job.inspection_id AND provider='qwen' ORDER BY created_at DESC LIMIT 1
            ) qwen ON true
            LEFT JOIN inspection_model_consensus consensus ON consensus.inspection_id=job.inspection_id
            ORDER BY job.created_at DESC LIMIT 100
            """
        ).fetchall()
        training_runs = conn.execute(
            """
            SELECT id,external_run_id,run_name,connector,model_family,base_model,dataset_version,
                   status,trigger_source,training_examples,validation_examples,training_images,
                   progress_percent,current_epoch,total_epochs,train_loss,validation_loss,
                   validation_accuracy,validation_macro_f1,crop_accuracy,issue_accuracy,
                   severity_accuracy,baseline_model,candidate_model,baseline_metrics,
                   candidate_metrics,quality_gate_json,promotion_status,deployment_status,
                   model_artifact_uri,started_at,completed_at,promoted_at,created_at,error_message
            FROM model_training_runs ORDER BY created_at DESC LIMIT 50
            """
        ).fetchall()
        training_events = conn.execute(
            """
            SELECT event.id,event.run_id,event.event_type,event.stage,event.progress_percent,
                   event.train_loss,event.validation_loss,event.metrics,event.message,event.created_at,
                   run.run_name
            FROM model_training_events event
            LEFT JOIN model_training_runs run ON run.id=event.run_id
            ORDER BY event.created_at DESC LIMIT 200
            """
        ).fetchall()
        versions = conn.execute(
            "SELECT * FROM model_versions ORDER BY COALESCE(deployed_at,created_at) DESC"
        ).fetchall()
        history = conn.execute(
            """
            WITH days AS (
                SELECT (result.created_at AT TIME ZONE 'Asia/Kolkata')::date AS day,
                       result.provider,result.model_name,count(*) AS attempts,
                       count(*) FILTER (WHERE result.success) AS successful,
                       avg(prediction.confidence) AS confidence,
                       avg(result.latency_ms) FILTER (WHERE result.success) AS latency_ms,
                        avg(consensus.agreement_count::numeric/3) AS agreement
                FROM ai_provider_results result
                LEFT JOIN LATERAL (
                    SELECT confidence FROM ai_predictions p WHERE p.inspection_id=result.inspection_id
                      AND p.provider=result.provider ORDER BY created_at DESC LIMIT 1
                ) prediction ON true
                LEFT JOIN inspection_model_consensus consensus ON consensus.inspection_id=result.inspection_id
                WHERE result.provider IN ('gemma','gemini','qwen') AND result.created_at>=now()-interval '30 days'
                GROUP BY day,result.provider,result.model_name
            )
            SELECT day,provider,model_name,attempts,successful,
                   round(successful::numeric*100/NULLIF(attempts,0),1) AS success_rate_percent,
                   round(confidence*100,1) AS confidence_percent,round(latency_ms,1) AS latency_ms,
                   round(agreement*100,1) AS agreement_percent
            FROM days ORDER BY day,CASE provider WHEN 'gemma' THEN 0 WHEN 'gemini' THEN 1 ELSE 2 END
            """
        ).fetchall()
        dataset = conn.execute(
            """
            SELECT (SELECT count(*) FROM inspections) AS total_inspections,
                   (SELECT count(*) FROM inspection_images WHERE storage_provider='s3' AND retention_status='retained') AS retained_images,
                   (SELECT count(*) FROM inspection_model_consensus WHERE successful_models=3) AS three_model_evaluations,
                   (SELECT count(*) FROM auto_training_candidates WHERE candidate_status='eligible') AS automatic_training_cases,
                   (SELECT count(*) FROM auto_training_candidates WHERE label_tier='three_model_consensus') AS three_model_labels,
                   (SELECT count(*) FROM auto_training_candidates WHERE label_tier='two_model_consensus') AS two_model_labels,
                   (SELECT count(*) FROM auto_training_candidates WHERE label_tier='gemini_flash_lite_fallback') AS gemini_fallback_labels,
                   (SELECT count(*) FROM auto_training_candidates WHERE candidate_status='waiting_models') AS retained_waiting_labels
            """
        ).fetchone()
        assistant_usage = conn.execute(
            """
            SELECT count(*) FILTER (WHERE (created_at AT TIME ZONE 'Asia/Kolkata')::date=(now() AT TIME ZONE 'Asia/Kolkata')::date) AS requests_today,
                   count(*) FILTER (WHERE status='completed' AND (created_at AT TIME ZONE 'Asia/Kolkata')::date=(now() AT TIME ZONE 'Asia/Kolkata')::date) AS completed_today,
                   count(*) FILTER (WHERE status IN ('failed','fallback') AND (created_at AT TIME ZONE 'Asia/Kolkata')::date=(now() AT TIME ZONE 'Asia/Kolkata')::date) AS failed_or_fallback_today
            FROM assistant_requests
            """
        ).fetchone()

    qwen_health = {"status": "disabled", "model": QWEN_MODEL}
    if QWEN_ENABLED and QWEN_SHADOW_MODE:
        try:
            request = Request(f"{QWEN_BASE_URL}/api/tags", headers={"Accept": "application/json"})
            with urlopen(request, timeout=3) as response:
                value = json.loads(response.read(512 * 1024))
            names = [item.get("name") for item in value.get("models", []) if isinstance(item, dict)]
            qwen_health = {"status": "available" if QWEN_MODEL in names else "model_missing", "model": QWEN_MODEL}
        except (HTTPError, URLError, TimeoutError, OSError, ValueError, json.JSONDecodeError):
            qwen_health = {"status": "offline", "model": QWEN_MODEL}
    return {
        "providers": providers,
        "models": {
            "live": {"provider": "gemma", "model": GEMMA_MODEL, "role": "preferred_live_with_flash_lite_fallback"},
            "fast_evaluator": {"provider": "gemini", "model": GEMINI_SHADOW_MODEL, "role": "live_fallback_and_training_teacher"},
            "private_evaluator": {"provider": "qwen", "model": QWEN_MODEL, "role": "student_evaluation_and_adapter_fine_tuning"},
        },
        "gemini": {"enabled": GEMINI_SHADOW_ENABLED, "runtime": gemini_runtime, "queue": gemini_queue},
        "qwen": {"health": qwen_health, "runtime": runtime, "queue": queue, "jobs": jobs},
        "pipeline": pipeline,
        "candidate_summary": candidate_summary,
        "candidates": candidates,
        "dataset": dataset,
        "training_runs": training_runs,
        "training_events": training_events,
        "model_versions": versions,
        "performance_history": history,
        "assistant_usage": {**dict(assistant_usage), "provider": "gemma", "model": GEMMA_MODEL},
        "automation": {
            "queue_policy": "process_immediately_whenever_gpu_is_reachable",
            "automatic_training": MODEL_TRAINING_AUTOSTART,
            "automatic_deployment": MODEL_AUTO_DEPLOY_ENABLED,
            "training_connector_configured": bool(GPU_TRAINING_SERVICE_URL and len(GPU_TRAINING_SERVICE_TOKEN) >= 32),
            "training_connector_status": (pipeline or {}).get("connector_status") or (
                "configured" if GPU_TRAINING_SERVICE_URL and len(GPU_TRAINING_SERVICE_TOKEN) >= 32 else "not_configured"
            ),
            "minimum_new_cases": MODEL_TRAINING_MIN_NEW_CASES,
            "minimum_confidence": MODEL_PIPELINE_MIN_CONFIDENCE,
            "minimum_issue_similarity": MODEL_PIPELINE_MIN_ISSUE_SIMILARITY,
            "label_hierarchy": ["three_model_consensus", "two_model_consensus", "gemini_flash_lite_fallback"],
            "promotion_gates": {
                "validation_accuracy": MODEL_AUTO_PROMOTE_MIN_ACCURACY,
                "macro_f1": MODEL_AUTO_PROMOTE_MIN_MACRO_F1,
                "issue_accuracy": MODEL_AUTO_PROMOTE_MIN_ISSUE_ACCURACY,
            },
        },
    }


@router.get("/access/employees")
def employee_access(identity: AdminIdentity = Depends(_identity)):
    _require(identity, {"employee_access_approver"})
    with connection() as conn:
        rows = conn.execute(
            """
            SELECT e.id, e.employee_code, e.full_name, e.office_email, e.microsoft_upn, e.department,
                   e.designation, e.location, e.status, e.reporting_manager_name,
                   e.hr_sync_state, e.hr_first_seen_at, e.hr_last_seen_at, e.hr_last_changed_at,
                   max(portal.email) AS portal_access_email,
                   bool_or(COALESCE(portal.active, false)) AS portal_access_active,
                   max(portal.invited_at) AS portal_invited_at,
                   max(portal.last_login_at) AS portal_last_login_at,
                   COALESCE(array_agg(er.role_code) FILTER (WHERE er.role_code IS NOT NULL), '{}') AS roles
            FROM employees e
            LEFT JOIN employee_roles er ON er.employee_id = e.id
            LEFT JOIN portal_password_accounts portal ON portal.employee_id = e.id
            GROUP BY e.id
            ORDER BY e.full_name
            """
        ).fetchall()
    return {"items": rows, "assignable_role_codes": sorted(ASSIGNABLE_ROLE_CODES)}


@router.put("/access/employees/{employee_id}/roles")
def set_employee_roles(employee_id: UUID, payload: EmployeeRoleAssignment, identity: AdminIdentity = Depends(_identity)):
    _require(identity, {"super_admin"})
    with connection() as conn:
        employee = conn.execute("SELECT id, employee_code, full_name FROM employees WHERE id = %s FOR UPDATE", (employee_id,)).fetchone()
        if not employee:
            raise HTTPException(status_code=404, detail="Employee not found.")
        existing = conn.execute("SELECT role_code FROM employee_roles WHERE employee_id = %s ORDER BY role_code", (employee_id,)).fetchall()
        old_roles = [row["role_code"] for row in existing]
        # Super Administrator is intentionally protected from browser editing.
        # Jiten's emergency access cannot be removed or granted from this screen.
        conn.execute("DELETE FROM employee_roles WHERE employee_id = %s AND role_code <> 'super_admin'", (employee_id,))
        for role in payload.roles:
            conn.execute(
                "INSERT INTO employee_roles(employee_id, role_code) VALUES (%s, %s) ON CONFLICT DO NOTHING",
                (employee_id, role),
            )
        new_roles = conn.execute("SELECT role_code FROM employee_roles WHERE employee_id = %s ORDER BY role_code", (employee_id,)).fetchall()
        _audit(conn, identity, "update_employee_roles", "employee", employee["employee_code"], {"roles": old_roles}, {"roles": [row["role_code"] for row in new_roles]})
        conn.commit()
    return {"id": str(employee_id), "employee_code": employee["employee_code"], "roles": [row["role_code"] for row in new_roles]}


@router.post("/access/employees/{employee_id}/invite")
def invite_employee_to_portal(employee_id: UUID, payload: PortalInvitation, identity: AdminIdentity = Depends(_identity)):
    """Assign the chosen profile and issue a password to one official email."""
    _require(identity, {"super_admin"})
    issuer_id = _employee_actor_id(identity)
    if issuer_id is None:
        raise HTTPException(403, "A real Super Administrator employee identity is required.")
    temporary_password = f"CL!{secrets.token_urlsafe(10)}9a"
    with connection() as conn:
        employee = conn.execute(
            """
            SELECT id, employee_code, full_name, lower(COALESCE(office_email, microsoft_upn)) AS email
            FROM employees WHERE id=%s AND status='active' FOR UPDATE
            """,
            (employee_id,),
        ).fetchone()
        if not employee:
            raise HTTPException(status_code=404, detail="Active employee not found.")
        if not employee["email"] or not employee["email"].endswith(f"@{ADMIN_ALLOWED_EMAIL_DOMAIN}"):
            raise HTTPException(status_code=422, detail="This employee needs an approved Crop Life work email before portal access can be issued.")
        existing = conn.execute("SELECT role_code FROM employee_roles WHERE employee_id=%s ORDER BY role_code", (employee_id,)).fetchall()
        old_roles = [row["role_code"] for row in existing]
        conn.execute("DELETE FROM employee_roles WHERE employee_id=%s AND role_code <> 'super_admin'", (employee_id,))
        for role in payload.roles:
            conn.execute(
                "INSERT INTO employee_roles(employee_id, role_code, granted_by) VALUES (%s,%s,%s) ON CONFLICT (employee_id, role_code) DO UPDATE SET granted_by=EXCLUDED.granted_by",
                (employee_id, role, issuer_id),
            )
        conn.execute(
            """
            INSERT INTO portal_password_accounts(employee_id, email, password_hash, invited_by, invited_at, active)
            VALUES (%s,%s,%s,%s,now(),true)
            ON CONFLICT (employee_id) DO UPDATE SET
                email=EXCLUDED.email, password_hash=EXCLUDED.password_hash,
                invited_by=EXCLUDED.invited_by, invited_at=now(), active=true
            """,
            (employee_id, employee["email"], _password_hash(temporary_password), issuer_id),
        )
        _audit(conn, identity, "invite_portal_employee", "employee", employee["employee_code"], {"roles": old_roles}, {"roles": payload.roles, "email": employee["email"]})
        conn.commit()
    email_sent, delivery_message = _send_portal_invitation(employee["email"], employee["full_name"], temporary_password, payload.roles)
    return {
        "employee_id": str(employee_id), "name": employee["full_name"], "email": employee["email"],
        "roles": payload.roles, "email_sent": email_sent, "delivery_message": delivery_message,
        "temporary_password": None if email_sent else temporary_password,
    }


@router.post('/sales-officers/access/reset')
def reset_sales_officer_field_access(identity: AdminIdentity = Depends(_identity)):
    """Invalidate every active Sales Officer app link without touching HR or inspection data."""
    _require(identity, {'super_admin'})
    issuer_id = _employee_actor_id(identity)
    if issuer_id is None:
        raise HTTPException(403, 'A real Super Administrator employee identity is required.')
    with connection() as conn:
        revoked = conn.execute(
            """
            UPDATE field_access_grants grant_record
            SET revoked_at=now()
            FROM sales_officer_territories roster
            JOIN employees employee ON employee.id=roster.employee_id
            WHERE grant_record.employee_id=roster.employee_id
              AND grant_record.revoked_at IS NULL
              AND employee.status <> 'inactive'
            RETURNING grant_record.employee_id
            """
        ).fetchall()
        _audit(
            conn, identity, 'reset_all_sales_officer_field_access', 'sales_officer_access', 'all_active_links',
            {'active_links': len(revoked)},
            {'revoked_links': len(revoked), 'employee_records_changed': False, 'inspection_records_changed': False},
        )
        conn.commit()
    return {
        'revoked_links': len(revoked),
        'message': 'All current Sales Officer field links were invalidated. Create fresh personal links when the pilot starts.',
    }


@router.post('/sales-officers/{roster_id}/access')
def issue_field_access(roster_id: UUID, identity: AdminIdentity = Depends(_identity)):
    _require(identity, {'super_admin'})
    issuer_id = _employee_actor_id(identity)
    if issuer_id is None:
        raise HTTPException(403, 'A real Super Administrator employee identity is required.')
    token = secrets.token_urlsafe(32)
    with connection() as conn:
        employee = conn.execute("SELECT e.id, e.full_name FROM sales_officer_territories s JOIN employees e ON e.id=s.employee_id WHERE s.id=%s AND e.status <> 'inactive'", (roster_id,)).fetchone()
        if not employee:
            raise HTTPException(422, 'Match this officer to an active employee first.')
        conn.execute('UPDATE field_access_grants SET revoked_at=now() WHERE employee_id=%s AND revoked_at IS NULL', (employee['id'],))
        grant = conn.execute("INSERT INTO field_access_grants(employee_id, token_hash, issued_by, expires_at) VALUES (%s,%s,%s,NULL) RETURNING created_at", (employee['id'], hashlib.sha256(token.encode()).hexdigest(), issuer_id)).fetchone()
        _audit(conn, identity, 'issue_field_access', 'employee', str(employee['id']), None, {'permanent_until_revoked': True, 'created_at': grant['created_at'].isoformat()})
        conn.commit()
    return {'token': token, 'permanent_until_revoked': True, 'name': employee['full_name']}


class CampaignInput(BaseModel):
    name: str = Field(min_length=2, max_length=180)
    discount_type: Literal["percentage", "fixed_amount"]
    discount_value: float = Field(gt=0)
    start_date: datetime
    end_date: datetime | None = None
    status: Literal["active", "paused", "completed"] = "active"
    campaign_type: Literal["welcome", "festival", "regional", "random", "general"] = "general"
    description: str = Field(default="", max_length=500)
    audience: Literal["new_farmer", "all_farmers", "targeted", "random"] = "all_farmers"
    states: list[str] = Field(default_factory=list, max_length=50)
    districts: list[str] = Field(default_factory=list, max_length=100)
    villages: list[str] = Field(default_factory=list, max_length=200)
    products: list[str] = Field(default_factory=list, max_length=100)
    coupon_limit: int = Field(default=0, ge=0, le=1000000)
    budget: float = Field(default=0, ge=0)
    random_percentage: int = Field(default=10, ge=1, le=100)
    expiry_days: int = Field(default=30, ge=1, le=365)

@router.get("/analytics/farmers")
def admin_analytics_farmers(identity: AdminIdentity = Depends(_identity)):
    _require(identity, ADMIN_READ_ROLES)
    with connection() as conn:
        active_farmers = conn.execute("SELECT usage_date, active_farmers FROM vw_daily_active_farmers ORDER BY usage_date DESC LIMIT 30").fetchall()
        total_farmers = conn.execute("SELECT COUNT(id) AS total FROM farmers").fetchone()["total"]
        return {"total_farmers": total_farmers, "daily_active_farmers": active_farmers}

@router.get("/analytics/dealers")
def admin_analytics_dealers(identity: AdminIdentity = Depends(_identity)):
    _require(identity, ADMIN_READ_ROLES)
    with connection() as conn:
        dealers = conn.execute("""
            SELECT d.id, d.name, COUNT(f.id) as acquired_farmers, COUNT(cr.id) as coupons_redeemed
            FROM dealers d
            LEFT JOIN farmers f ON f.acquisition_dealer_id = d.id
            LEFT JOIN coupon_redemptions cr ON cr.dealer_id = d.id
            GROUP BY d.id
            ORDER BY acquired_farmers DESC LIMIT 50
        """).fetchall()
        return {"items": dealers}

@router.get("/analytics/ai-costs")
def admin_analytics_ai_costs(identity: AdminIdentity = Depends(_identity)):
    _require(identity, ADMIN_READ_ROLES)
    with connection() as conn:
        costs = conn.execute("""
            SELECT provider, model_name, SUM(input_tokens) as total_input_tokens, 
                   SUM(output_tokens) as total_output_tokens,
                   (SUM(input_tokens) * 1.50 / 1000000.0 * 84.0 + SUM(output_tokens) * 9.0 / 1000000.0 * 84.0) as estimated_inr_cost
            FROM ai_usage
            GROUP BY provider, model_name
        """).fetchall()
        return {"items": costs}

@router.get("/campaigns")
def get_campaigns(identity: AdminIdentity = Depends(_identity)):
    _require(identity, ADMIN_READ_ROLES)
    with connection() as conn:
        campaigns = conn.execute("SELECT * FROM campaigns ORDER BY created_at DESC").fetchall()
    return {"items": campaigns}

@router.post("/campaigns")
def create_campaign(payload: CampaignInput, identity: AdminIdentity = Depends(_identity)):
    _require(identity, CATALOGUE_MANAGER_ROLES)
    if payload.end_date and payload.end_date <= payload.start_date:
        raise HTTPException(400, "Campaign end date must be after its start date.")
    rules = {
        "campaign_type": payload.campaign_type, "description": payload.description.strip(), "audience": payload.audience,
        "states": payload.states, "districts": payload.districts, "villages": payload.villages, "products": payload.products,
        "coupon_limit": payload.coupon_limit, "budget": payload.budget, "random_percentage": payload.random_percentage,
        "expiry_days": payload.expiry_days,
    }
    with connection() as conn:
        row = conn.execute(
            """
            INSERT INTO campaigns(name, discount_type, discount_value, start_date, end_date, status, rules)
            VALUES (%s, %s, %s, %s, %s, %s, %s::jsonb) RETURNING id
            """,
            (payload.name, payload.discount_type, payload.discount_value, payload.start_date, payload.end_date, payload.status, json.dumps(rules))
        ).fetchone()
        conn.commit()
    return {"status": "success", "campaign_id": str(row["id"])}

class CampaignStatusInput(BaseModel):
    status: Literal["active", "paused", "completed"]

@router.put("/campaigns/{campaign_id}/status")
def update_campaign_status(campaign_id: UUID, payload: CampaignStatusInput, identity: AdminIdentity = Depends(_identity)):
    _require(identity, CATALOGUE_MANAGER_ROLES)
    with connection() as conn:
        conn.execute("UPDATE campaigns SET status = %s, updated_at = now() WHERE id = %s", (payload.status, campaign_id))
        conn.commit()
    return {"status": "success"}

class BulkCouponInput(BaseModel):
    count: int = Field(gt=0, le=5000)

@router.post("/campaigns/{campaign_id}/bulk-generate")
def bulk_generate_coupons(campaign_id: UUID, payload: BulkCouponInput, identity: AdminIdentity = Depends(_identity)):
    _require(identity, CATALOGUE_MANAGER_ROLES)
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    
    with connection() as conn:
        # verify campaign exists
        cam = conn.execute("SELECT id,rules FROM campaigns WHERE id = %s", (campaign_id,)).fetchone()
        if not cam:
            raise HTTPException(status_code=404, detail="Campaign not found")
        limit = int((cam.get("rules") or {}).get("coupon_limit") or 0)
        existing_count = conn.execute("SELECT COUNT(*) AS count FROM coupons WHERE campaign_id=%s", (campaign_id,)).fetchone()["count"]
        target_count = min(payload.count, max(0, limit-existing_count)) if limit else payload.count
        inserted = 0
        attempts = 0
        while inserted < target_count and attempts < max(4, target_count * 4):
            attempts += 1
            code = ''.join(secrets.choice(alphabet) for _ in range(7))
            row = conn.execute(
                """INSERT INTO coupons(code,campaign_id,status) VALUES(%s,%s,'available')
                   ON CONFLICT(code) DO NOTHING RETURNING id""",
                (code, campaign_id),
            ).fetchone()
            if row:
                inserted += 1
        conn.commit()
        
    return {"status": "success", "generated_count": inserted}

@router.get("/campaigns/analytics")
def get_campaigns_analytics(identity: AdminIdentity = Depends(_identity)):
    _require(identity, ADMIN_READ_ROLES)
    with connection() as conn:
        stats = conn.execute("""
            SELECT 
                c.id as campaign_id,
                c.name,
                c.status,
                c.discount_type,
                c.discount_value,c.start_date,c.end_date,c.rules,
                (SELECT COUNT(*) FROM coupons cp WHERE cp.campaign_id=c.id) as total_issued,
                (SELECT COUNT(*) FROM coupons cp WHERE cp.campaign_id=c.id AND cp.status='available') as total_available,
                (SELECT COUNT(*) FROM coupons cp WHERE cp.campaign_id=c.id AND cp.status='issued') as total_assigned,
                (SELECT COUNT(*) FROM coupons cp WHERE cp.campaign_id=c.id AND cp.status='redeemed') as total_redeemed,
                (SELECT COALESCE(SUM(cr.amount_redeemed),0)
                   FROM coupon_redemptions cr JOIN coupons cp ON cp.id=cr.coupon_id
                  WHERE cp.campaign_id=c.id) as total_spend
            FROM campaigns c
            ORDER BY c.created_at DESC
        """).fetchall()
        
        # Calculate total overall spend
        total_overall_spend = sum((s["total_spend"] or 0) for s in stats)
        
    return {"items": stats, "total_spend": total_overall_spend}

class ExpertReviewInput(BaseModel):
    review_status: Literal["Correct", "Partially Correct", "Incorrect", "Corrected", "Reject"]
    training_eligible: bool
    expert_final_label: str | None = None
    note: str | None = None

@router.post("/inspections/{inspection_id}/expert-review")
def create_expert_review(inspection_id: UUID, payload: ExpertReviewInput, identity: AdminIdentity = Depends(_identity)):
    _require(identity, INSPECTION_REVIEW_ROLES)
    with connection() as conn:
        row = conn.execute(
            """
            INSERT INTO expert_reviews(inspection_id, reviewer_employee_id, review_status, 
                                       expert_final_label, training_eligible, note)
            VALUES (%s, %s, %s, %s, %s, %s) RETURNING id
            """,
            (inspection_id, _employee_actor_id(identity), payload.review_status, 
             payload.expert_final_label, payload.training_eligible, payload.note)
        ).fetchone()
        
        conn.execute("UPDATE inspections SET dataset_quality_status = %s, training_eligible = %s WHERE id = %s", 
                     (payload.review_status, payload.training_eligible, inspection_id))
        conn.commit()
    return {"status": "success", "review_id": str(row["id"])}


@router.get("/dealers")
def list_dealers(
    search: str = Query(default="", max_length=120),
    state: str = Query(default="", max_length=100),
    area: str = Query(default="", max_length=100),
    territory: str = Query(default="", max_length=100),
    status: str = Query(default="", max_length=32),
    phone: str = Query(default="", max_length=20),
    account: str = Query(default="", max_length=24),
    test_data: str = Query(default="", max_length=10),
    limit: int = Query(default=500, ge=0, le=5000),
    offset: int = Query(default=0, ge=0),
    identity: AdminIdentity = Depends(_identity)
):
    _require(identity, SALES_ACTIVITY_ROLES)
    filters = []
    params = []
    if search.strip():
        filters.append("""(
            COALESCE(name, '') ILIKE %s OR COALESCE(dealer_code, '') ILIKE %s
            OR COALESCE(sales_executive, '') ILIKE %s OR COALESCE(sales_area, '') ILIKE %s
            OR COALESCE(sales_region, '') ILIKE %s OR COALESCE(sales_territory, '') ILIKE %s
            OR COALESCE(state, '') ILIKE %s OR COALESCE(location, '') ILIKE %s
        )""")
        term = f"%{search.strip()}%"
        params.extend([term] * 8)
    
    if state:
        filters.append("LOWER(BTRIM(COALESCE(state, ''))) = LOWER(BTRIM(%s))")
        params.append(state)
    if area:
        filters.append("LOWER(BTRIM(COALESCE(sales_area, ''))) = LOWER(BTRIM(%s))")
        params.append(area)
    if territory:
        filters.append("LOWER(BTRIM(COALESCE(sales_territory, ''))) = LOWER(BTRIM(%s))")
        params.append(territory)
    if status:
        filters.append("LOWER(BTRIM(COALESCE(status, ''))) = LOWER(BTRIM(%s))")
        params.append(status)
    if phone.strip():
        filters.append("COALESCE(portal_mobile_number, '') ILIKE %s")
        params.append(f"%{phone.strip()}%")
    if account == "generated":
        filters.append("dealer_code IS NOT NULL AND owner_name IS NOT NULL AND portal_mobile_number IS NOT NULL")
    elif account == "not_generated":
        filters.append("(dealer_code IS NULL OR owner_name IS NULL OR portal_mobile_number IS NULL)")
    elif account == "verified":
        filters.append("dealer_code IS NOT NULL AND owner_name IS NOT NULL AND portal_mobile_number IS NOT NULL AND EXISTS (SELECT 1 FROM dealer_referrals x WHERE x.dealer_id=dealers.id)")
    if test_data == "yes": filters.append("is_test=true")
    elif test_data == "no": filters.append("is_test=false")
        
    where_clause = f"WHERE {' AND '.join(filters)}" if filters else ""
    sql = f"""SELECT dealers.id, dealer_code, name, owner_name, location, sales_executive, sales_area, sales_region,
        sales_territory, state, status, portal_mobile_number, is_test, account_generated_at,
        (SELECT referral_token FROM dealer_referrals dr WHERE dr.dealer_id=dealers.id ORDER BY created_at DESC LIMIT 1) referral_token,
        (SELECT COUNT(*) FROM farmers f WHERE COALESCE(f.acquisition_dealer_id,f.preferred_dealer_id,f.verified_dealer_id)=dealers.id) farmer_count,
        (SELECT COUNT(*) FROM coupon_redemptions cr WHERE cr.dealer_id=dealers.id) redemption_count,
        COALESCE((SELECT SUM(cr.amount_redeemed) FROM coupon_redemptions cr WHERE cr.dealer_id=dealers.id),0) redeemed_amount,
        COALESCE((SELECT SUM(cr.amount_redeemed) FROM coupon_redemptions cr WHERE cr.dealer_id=dealers.id AND cr.credit_note_id IS NULL),0) outstanding_amount,
        COALESCE((SELECT SUM(total_amount) FROM dealer_credit_notes cn WHERE cn.dealer_id=dealers.id AND cn.status='settled'),0) settled_amount
        FROM dealers {where_clause} ORDER BY is_test DESC, name"""
    count_sql = f"SELECT COUNT(*) as c FROM dealers {where_clause}"
    
    with connection() as conn:
        rows = conn.execute(sql if limit == 0 else sql + " LIMIT %s OFFSET %s", params if limit == 0 else params + [limit, offset]).fetchall()
        total = conn.execute(count_sql, params).fetchone()["c"]
        facets = conn.execute(
            """SELECT ARRAY(SELECT DISTINCT BTRIM(state) FROM dealers WHERE BTRIM(COALESCE(state, ''))<>'' ORDER BY BTRIM(state)) AS states,
                      ARRAY(SELECT DISTINCT BTRIM(sales_area) FROM dealers WHERE BTRIM(COALESCE(sales_area, ''))<>'' ORDER BY BTRIM(sales_area)) AS areas,
                      ARRAY(SELECT DISTINCT BTRIM(sales_territory) FROM dealers WHERE BTRIM(COALESCE(sales_territory, ''))<>'' ORDER BY BTRIM(sales_territory)) AS territories"""
        ).fetchone()
        
    return {"items": rows, "facets": facets, "total": total}

class DealerPayload(BaseModel):
    # Dealer codes are generated by the server and are never editable once
    # issued.  This prevents predictable codes and prevents an edit from
    # breaking an existing dealer's sign-in or referral QR.
    dealer_code: Optional[str] = Field(default=None, max_length=64)
    name: str = Field(..., max_length=180)
    owner_name: Optional[str] = Field(default=None, max_length=180)
    sales_executive: Optional[str] = Field(default=None, max_length=180)
    sales_area: Optional[str] = Field(default=None, max_length=100)
    sales_region: Optional[str] = Field(default=None, max_length=100)
    sales_territory: Optional[str] = Field(default=None, max_length=100)
    state: Optional[str] = Field(default=None, max_length=100)
    status: Literal["active", "inactive"] = "active"
    portal_mobile_number: Optional[str] = Field(default=None, max_length=20)

    @field_validator("portal_mobile_number")
    @classmethod
    def canonical_portal_mobile(cls, value: Optional[str]) -> Optional[str]:
        if not value:
            return None
        digits = "".join(character for character in value if character.isdigit())
        if len(digits) == 10:
            return "+91" + digits
        if 10 <= len(digits) <= 15 and value.strip().startswith("+"):
            return "+" + digits
        raise ValueError("Use a valid mobile number including the country code when it is not Indian.")


def _new_dealer_code() -> str:
    return "DLR-" + secrets.token_hex(10).upper()


def _new_short_referral_code() -> str:
    return "".join(secrets.choice(_REFERRAL_ALPHABET) for _ in range(7))


def _assert_portal_mobile_available(conn, mobile_number: Optional[str], dealer_id: UUID | None = None) -> None:
    if not mobile_number:
        return
    if dealer_id is None:
        existing = conn.execute("SELECT 1 FROM dealers WHERE portal_mobile_number=%s LIMIT 1", (mobile_number,)).fetchone()
    else:
        existing = conn.execute("SELECT 1 FROM dealers WHERE portal_mobile_number=%s AND id<>%s LIMIT 1", (mobile_number, dealer_id)).fetchone()
    if existing:
        raise HTTPException(409, "This mobile number is already linked to another dealership.")

@router.post("/dealers")
def create_dealer(payload: DealerPayload, identity: AdminIdentity = Depends(_identity)):
    _require(identity, DEALER_WRITE_ROLES)
    # Only the super administrator can attach or replace the phone that
    # controls a dealer portal. Managers can create the operating record, but
    # cannot silently take over a dealer account.
    if payload.portal_mobile_number and not _can(identity, {"super_admin"}):
        raise HTTPException(403, "Only the super administrator can set a dealer portal mobile number.")
    with connection() as conn:
        _assert_portal_mobile_available(conn, payload.portal_mobile_number)
        for _ in range(3):
            row = conn.execute(
                """INSERT INTO dealers (dealer_code, master_code, name, owner_name, sales_executive, sales_area, sales_region, sales_territory, state, status, portal_mobile_number)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                   ON CONFLICT (dealer_code) DO NOTHING RETURNING *""",
                (None, "MANUAL-" + uuid4().hex.upper(), payload.name.strip(), payload.owner_name, payload.sales_executive, payload.sales_area, payload.sales_region, payload.sales_territory, payload.state, payload.status, payload.portal_mobile_number),
            ).fetchone()
            if row:
                _audit(conn, identity, "create", "dealer", str(row["id"]), None, {"name": row["name"]})
                conn.commit()
                return row
        raise HTTPException(503, "Could not allocate a secure dealer code. Please try again.")

@router.put("/dealers/{dealer_id}")
def update_dealer(dealer_id: UUID, payload: DealerPayload, identity: AdminIdentity = Depends(_identity)):
    _require(identity, DEALER_WRITE_ROLES)
    with connection() as conn:
        existing = conn.execute("SELECT * FROM dealers WHERE id=%s FOR UPDATE", (dealer_id,)).fetchone()
        if not existing:
            raise HTTPException(404, "Dealer not found.")
        if payload.portal_mobile_number != existing["portal_mobile_number"] and not _can(identity, {"super_admin"}):
            raise HTTPException(403, "Only the super administrator can change a dealer portal mobile number.")
        _assert_portal_mobile_available(conn, payload.portal_mobile_number, dealer_id)
        row = conn.execute(
            """UPDATE dealers SET name=%s, owner_name=%s, sales_executive=%s, sales_area=%s,
                   sales_region=%s, sales_territory=%s, state=%s, status=%s, portal_mobile_number=%s,
                   updated_at=now() WHERE id=%s RETURNING *""",
            (payload.name.strip(), payload.owner_name, payload.sales_executive, payload.sales_area,
             payload.sales_region, payload.sales_territory, payload.state, payload.status,
             payload.portal_mobile_number, dealer_id),
        ).fetchone()
        _audit(conn, identity, "update", "dealer", str(dealer_id), existing, row)
        conn.commit()
        return row

@router.delete("/dealers/{dealer_id}")
def delete_dealer(dealer_id: UUID, identity: AdminIdentity = Depends(_identity)):
    _require(identity, DEALER_ARCHIVE_ROLES)
    with connection() as conn:
        archived = conn.execute("UPDATE dealers SET status='inactive', updated_at=now() WHERE id=%s RETURNING id, name", (dealer_id,)).fetchone()
        if not archived:
            raise HTTPException(404, "Dealer not found")
        _audit(conn, identity, "archive", "dealer", str(dealer_id), None, {"status": "inactive"})
        conn.commit()
        return {"status": "success", "message": "Dealer archived and no longer available for new portal sign-ins."}

@router.post("/dealers/import")
def import_dealers(file: UploadFile = File(...), identity: AdminIdentity = Depends(_identity)):
    _require(identity, DEALER_WRITE_ROLES)
    if not file.filename or not file.filename.lower().endswith('.csv'):
        raise HTTPException(400, "Only CSV files are allowed.")
    
    contents = file.file.read()
    try:
        decoded = contents.decode('utf-8')
    except UnicodeDecodeError:
        raise HTTPException(400, "Invalid file encoding. Please upload a UTF-8 encoded CSV.")
        
    reader = csv.DictReader(io.StringIO(decoded))
    
    required_fields = ['dealer_code', 'name']
    for field in required_fields:
        if field not in (reader.fieldnames or []):
            raise HTTPException(400, f"Missing required column: {field}")

    imported_count = 0
    updated_count = 0
    
    with connection() as conn:
        for row in reader:
            dealer_code = row.get('dealer_code', '').strip()
            if not dealer_code:
                continue
            
            name = row.get('name', '').strip()
            if not name:
                continue
            owner_name = row.get('owner_name', '').strip() or None
            sales_executive = row.get('sales_executive', '').strip() or None
            sales_area = row.get('sales_area', '').strip() or None
            sales_region = row.get('sales_region', '').strip() or None
            sales_territory = row.get('sales_territory', '').strip() or None
            state = row.get('state', '').strip() or None

            # A CSV master code is an internal matching key. It never replaces
            # an issued public dealer code or a bound portal mobile number.
            existing = conn.execute(
                "SELECT id FROM dealers WHERE master_code=%s OR dealer_code=%s LIMIT 1",
                (dealer_code, dealer_code),
            ).fetchone()
            
            if existing:
                conn.execute(
                    """UPDATE dealers SET name=%s, owner_name=%s, sales_executive=%s, sales_area=%s,
                       sales_region=%s, sales_territory=%s, state=%s, updated_at=now()
                       WHERE id=%s""",
                    (name, owner_name, sales_executive, sales_area, sales_region, sales_territory, state, existing['id'])
                )
                updated_count += 1
            else:
                conn.execute(
                    """INSERT INTO dealers (dealer_code, master_code, name, owner_name, sales_executive, sales_area,
                       sales_region, sales_territory, state)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                    (None, dealer_code, name, owner_name, sales_executive, sales_area,
                     sales_region, sales_territory, state)
                )
                imported_count += 1
                
        conn.commit()
    
    return {"message": f"Successfully imported {imported_count} new dealers and updated {updated_count} existing dealers."}


@router.post("/dealers/{dealer_id}/referral")
def generate_dealer_referral(dealer_id: UUID, identity: AdminIdentity = Depends(_identity)):
    _require(identity, DEALER_WRITE_ROLES)
    with connection() as conn:
        dealer = conn.execute("SELECT dealer_code,owner_name,portal_mobile_number FROM dealers WHERE id=%s", (dealer_id,)).fetchone()
        if not dealer or not dealer["dealer_code"] or not dealer["owner_name"] or not dealer["portal_mobile_number"]:
            raise HTTPException(400, "Generate the dealer account with owner name and mobile number first.")
        existing = conn.execute("SELECT referral_token FROM dealer_referrals WHERE dealer_id = %s LIMIT 1", (dealer_id,)).fetchone()
        token = existing["referral_token"] if existing else ""
        if len(token) != 7 or not token.isalnum():
            token = _new_short_referral_code()
        if existing:
            conn.execute("UPDATE dealer_referrals SET referral_token=%s WHERE dealer_id=%s", (token, dealer_id))
            conn.commit()
        else:
            conn.execute(
                "INSERT INTO dealer_referrals(dealer_id, referral_token) VALUES (%s, %s)",
                (dealer_id, token)
            )
            conn.commit()
            
    download_url = f"https://ai.croplifescience.com/?ref={token}"
    return {"token": token, "download_url": download_url}


class DealerAccountPayload(BaseModel):
    owner_name: str = Field(min_length=2, max_length=180)
    portal_mobile_number: str = Field(min_length=10, max_length=20)


@router.post("/dealers/{dealer_id}/generate-account")
def generate_dealer_account(dealer_id: UUID, payload: DealerAccountPayload, identity: AdminIdentity = Depends(_identity)):
    _require(identity, DEALER_WRITE_ROLES)
    digits = "".join(character for character in payload.portal_mobile_number if character.isdigit())
    if len(digits) == 10:
        mobile = "+91" + digits
    elif 10 <= len(digits) <= 15 and payload.portal_mobile_number.strip().startswith("+"):
        mobile = "+" + digits
    else:
        raise HTTPException(400, "Use a valid mobile number including the country code when it is not Indian.")
    with connection() as conn:
        dealer = conn.execute("SELECT * FROM dealers WHERE id=%s FOR UPDATE", (dealer_id,)).fetchone()
        if not dealer: raise HTTPException(404, "Dealer not found.")
        _assert_portal_mobile_available(conn, mobile, dealer_id)
        code = dealer["dealer_code"] or _new_dealer_code()
        updated = conn.execute(
            """UPDATE dealers SET dealer_code=%s,owner_name=%s,portal_mobile_number=%s,
                      account_generated_at=COALESCE(account_generated_at,now()),updated_at=now()
               WHERE id=%s
               RETURNING id,dealer_code,name,owner_name,portal_mobile_number,location,sales_area,sales_territory,state,status""",
            (code,payload.owner_name.strip(),mobile,dealer_id),
        ).fetchone()
        referral = conn.execute("SELECT referral_token FROM dealer_referrals WHERE dealer_id=%s LIMIT 1", (dealer_id,)).fetchone()
        token = referral["referral_token"] if referral else ""
        if len(token) != 7 or not token.isalnum(): token = _new_short_referral_code()
        if referral: conn.execute("UPDATE dealer_referrals SET referral_token=%s WHERE dealer_id=%s", (token,dealer_id))
        else: conn.execute("INSERT INTO dealer_referrals(dealer_id,referral_token) VALUES(%s,%s)", (dealer_id,token))
        _audit(conn, identity, "generate_account", "dealer", str(dealer_id), None, {"dealer_code":code,"referral_token":token})
        conn.commit()
    return {
        "status":"success",
        "dealer_code":code,
        "referral_token":token,
        "download_url":f"https://ai.croplifescience.com/?ref={token}",
        "dealer":updated,
    }


class CreditNotePayload(BaseModel):
    dealer_id: UUID
    period_start: date
    period_end: date

class SettleCreditNotePayload(BaseModel):
    settlement_reference: str = Field(min_length=2,max_length=120)
    note: Optional[str] = Field(default=None,max_length=1000)

@router.get("/dealer-credit-notes")
def list_credit_notes(identity: AdminIdentity = Depends(_identity)):
    _require(identity, ADMIN_READ_ROLES)
    with connection() as conn:
        rows=conn.execute("""SELECT cn.*,d.name dealer_name,d.dealer_code FROM dealer_credit_notes cn JOIN dealers d ON d.id=cn.dealer_id ORDER BY cn.generated_at DESC LIMIT 500""").fetchall()
    return {"items":rows}

@router.post("/dealer-credit-notes")
def generate_credit_note(payload: CreditNotePayload, identity: AdminIdentity = Depends(_identity)):
    _require(identity, DEALER_WRITE_ROLES)
    if payload.period_end < payload.period_start: raise HTTPException(400,"End date must be after start date.")
    with connection() as conn:
        dealer=conn.execute("SELECT name FROM dealers WHERE id=%s",(payload.dealer_id,)).fetchone()
        if not dealer: raise HTTPException(404,"Dealer not found.")
        totals=conn.execute("""SELECT COUNT(*) c,COALESCE(SUM(amount_redeemed),0) amount FROM coupon_redemptions WHERE dealer_id=%s AND redeemed_at::date BETWEEN %s AND %s AND credit_note_id IS NULL""",(payload.dealer_id,payload.period_start,payload.period_end)).fetchone()
        if not totals["c"]: raise HTTPException(400,"No unsettled coupon redemptions in this period.")
        number=f"CLSL-CN-{datetime.now().strftime('%Y%m%d')}-{secrets.randbelow(100000):05d}"
        note=conn.execute("""INSERT INTO dealer_credit_notes(dealer_id,note_number,period_start,period_end,redemption_count,total_amount,generated_by) VALUES(%s,%s,%s,%s,%s,%s,%s) RETURNING *""",(payload.dealer_id,number,payload.period_start,payload.period_end,totals["c"],totals["amount"],identity.email)).fetchone()
        conn.execute("UPDATE coupon_redemptions SET credit_note_id=%s WHERE dealer_id=%s AND redeemed_at::date BETWEEN %s AND %s AND credit_note_id IS NULL",(note["id"],payload.dealer_id,payload.period_start,payload.period_end))
        conn.commit()
    return note

@router.post("/dealer-credit-notes/{note_id}/settle")
def settle_credit_note(note_id: UUID,payload:SettleCreditNotePayload,identity:AdminIdentity=Depends(_identity)):
    _require(identity, DEALER_WRITE_ROLES)
    with connection() as conn:
        row=conn.execute("UPDATE dealer_credit_notes SET status='settled',settled_at=now(),settlement_reference=%s,settlement_note=%s WHERE id=%s AND status<>'settled' RETURNING *",(payload.settlement_reference,payload.note,note_id)).fetchone()
        if not row: raise HTTPException(404,"Open credit note not found.")
        conn.commit()
    return row

@router.get("/dealer-credit-notes/{note_id}/download")
def download_credit_note(note_id: UUID,identity:AdminIdentity=Depends(_identity)):
    _require(identity, ADMIN_READ_ROLES)
    with connection() as conn:
        note=conn.execute("SELECT cn.*,d.name dealer_name,d.owner_name,d.dealer_code,d.state,d.sales_territory FROM dealer_credit_notes cn JOIN dealers d ON d.id=cn.dealer_id WHERE cn.id=%s",(note_id,)).fetchone()
        if not note: raise HTTPException(404,"Credit note not found.")
        items=conn.execute("""SELECT c.code,cp.name campaign,cr.redeemed_at,cr.purchase_reference,cr.amount_redeemed FROM coupon_redemptions cr JOIN coupons c ON c.id=cr.coupon_id JOIN campaigns cp ON cp.id=c.campaign_id WHERE cr.credit_note_id=%s ORDER BY cr.redeemed_at""",(note_id,)).fetchall()
    rows=''.join(f"<tr><td>{html.escape(str(i['code']))}</td><td>{html.escape(str(i['campaign']))}</td><td>{i['redeemed_at'].date()}</td><td>{html.escape(str(i['purchase_reference'] or ''))}</td><td>₹{float(i['amount_redeemed'] or 0):,.2f}</td></tr>" for i in items)
    body=f"""<!doctype html><meta charset='utf-8'><title>{note['note_number']}</title><style>body{{font-family:Arial;padding:40px;color:#123}}h1{{color:#064878}}table{{width:100%;border-collapse:collapse}}th,td{{padding:10px;border:1px solid #ccd}}th{{background:#064878;color:white}}.total{{text-align:right;font-size:20px}}</style><h1>Crop Life Science Limited</h1><h2>Dealer Credit Note · {note['note_number']}</h2><p><b>Dealer:</b> {html.escape(note['dealer_name'])} · {html.escape(str(note['dealer_code'] or ''))}<br><b>Period:</b> {note['period_start']} to {note['period_end']}<br><b>Status:</b> {note['status'].upper()}</p><table><thead><tr><th>Coupon</th><th>Campaign</th><th>Redeemed</th><th>Reference</th><th>Amount</th></tr></thead><tbody>{rows}</tbody></table><p class='total'><b>Total credit: ₹{float(note['total_amount']):,.2f}</b></p><p>Generated for internal accounts verification. Print or save this page as PDF.</p>"""
    return Response(body,media_type="text/html",headers={"Content-Disposition":f"attachment; filename={note['note_number']}.html"})


# ---------------------------------------------------------------------------
# Dealer redemption summary (for credit note generation)
# ---------------------------------------------------------------------------


@router.get("/dealers/redemption-summary")
def dealer_redemption_summary(
    month: str = Query(default="", description="YYYY-MM, defaults to current month"),
    identity: AdminIdentity = Depends(_identity),
):
    """Return per-dealer coupon redemption totals for a given month.

    The CLSL team uses this report to generate credit notes at month end.
    Provide ?month=2026-09 to query a past month; omit for current month.
    """
    _require(identity, ADMIN_READ_ROLES)

    from datetime import timezone

    try:
        if month:
            year, mon = map(int, month.split("-"))
            month_start = datetime(year, mon, 1, tzinfo=timezone.utc)
        else:
            now = datetime.now(timezone.utc)
            month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        year_m, mon_m = month_start.year, month_start.month
        if mon_m == 12:
            month_end = month_start.replace(year=year_m + 1, month=1)
        else:
            month_end = month_start.replace(month=mon_m + 1)
    except (ValueError, AttributeError):
        raise HTTPException(400, "Invalid month format. Use YYYY-MM.")

    month_label = month_start.strftime("%B %Y")

    with connection() as conn:
        rows = conn.execute(
            """SELECT d.id, d.dealer_code, d.name, d.state, d.sales_territory,
                      d.portal_mobile_number,
                      COUNT(cr.id)                            AS redemption_count,
                      COALESCE(SUM(cr.amount_redeemed), 0)   AS total_amount,
                      COUNT(f.id)                             AS farmers_referred
               FROM dealers d
               LEFT JOIN coupon_redemptions cr
                      ON cr.dealer_id = d.id
                     AND cr.redeemed_at >= %s
                     AND cr.redeemed_at < %s
               LEFT JOIN farmers f
                      ON f.verified_dealer_id = d.id
                     AND f.location_consent_at >= %s
                     AND f.location_consent_at < %s
               WHERE d.status = 'active'
               GROUP BY d.id
               ORDER BY total_amount DESC, redemption_count DESC, d.name""",
            (
                month_start.isoformat(), month_end.isoformat(),
                month_start.isoformat(), month_end.isoformat(),
            ),
        ).fetchall()

    items = [
        {
            "dealer_id": str(r["id"]),
            "dealer_code": r["dealer_code"],
            "name": r["name"],
            "state": r["state"],
            "sales_territory": r["sales_territory"],
            "portal_mobile_number": r["portal_mobile_number"],
            "redemption_count": int(r["redemption_count"]),
            "total_amount": float(r["total_amount"]),
            "farmers_referred": int(r["farmers_referred"]),
        }
        for r in rows
    ]

    return {
        "month": month_label,
        "month_start": month_start.date().isoformat(),
        "month_end": month_end.date().isoformat(),
        "total_dealers": len(items),
        "grand_total_amount": sum(i["total_amount"] for i in items),
        "grand_total_redemptions": sum(i["redemption_count"] for i in items),
        "items": items,
    }


@router.get("/farmers")
def list_farmers(
    search: str = Query(default="", max_length=120),
    state: str = Query(default="", max_length=100),
    city: str = Query(default="", max_length=100),
    village: str = Query(default="", max_length=100),
    dealer_code: str = Query(default="", max_length=100),
    limit: int = Query(default=500, ge=0, le=5000),
    offset: int = Query(default=0, ge=0),
    identity: AdminIdentity = Depends(_identity)
):
    _require(identity, SALES_ACTIVITY_ROLES)
    filters = []
    params = []
    
    if search.strip():
        filters.append("(f.name ILIKE %s OR f.last_name ILIKE %s OR f.mobile_number ILIKE %s)")
        params.extend([f"%{search.strip()}%"] * 3)
        
    if state:
        filters.append("LOWER(BTRIM(COALESCE(f.state, ''))) = LOWER(BTRIM(%s))")
        params.append(state)
        
    if city:
        filters.append("LOWER(BTRIM(COALESCE(f.city, ''))) = LOWER(BTRIM(%s))")
        params.append(city)
        
    if village:
        filters.append("LOWER(BTRIM(COALESCE(f.village, ''))) = LOWER(BTRIM(%s))")
        params.append(village)
        
    if dealer_code:
        filters.append("d.dealer_code ILIKE %s")
        params.append(f"%{dealer_code.strip()}%")

    where_clause = f"WHERE {' AND '.join(filters)}" if filters else ""
    sql = f"""
        SELECT f.id, f.mobile_number, f.name AS first_name, f.last_name, f.role, f.city, f.state,
               f.district, f.village, f.created_at, f.last_login_at, f.is_verified, 
               d.dealer_code, d.name AS dealer_name
        FROM farmers f
        LEFT JOIN dealers d ON COALESCE(f.acquisition_dealer_id, f.preferred_dealer_id, f.verified_dealer_id) = d.id
        {where_clause}
        ORDER BY f.created_at DESC
    """
    with connection() as conn:
        rows = conn.execute(sql if limit == 0 else sql + " LIMIT %s OFFSET %s", params if limit == 0 else params + [limit, offset]).fetchall()
        total = conn.execute(
            f"""SELECT COUNT(*) AS total FROM farmers f
                LEFT JOIN dealers d ON COALESCE(f.acquisition_dealer_id, f.preferred_dealer_id, f.verified_dealer_id) = d.id
                {where_clause}""",
            params,
        ).fetchone()["total"]
        facets = conn.execute(
            """SELECT 
               ARRAY(SELECT DISTINCT BTRIM(state) FROM farmers WHERE BTRIM(COALESCE(state, ''))<>'' ORDER BY BTRIM(state)) AS states,
               ARRAY(SELECT DISTINCT BTRIM(city) FROM farmers WHERE BTRIM(COALESCE(city, ''))<>'' ORDER BY BTRIM(city)) AS cities,
               ARRAY(SELECT DISTINCT BTRIM(village) FROM farmers WHERE BTRIM(COALESCE(village, ''))<>'' ORDER BY BTRIM(village)) AS villages
               """
        ).fetchone()
        
    return {"items": rows, "facets": facets, "total": total, "offset": offset, "limit": limit}


@router.get("/login-audit")
def login_audit(
    date: str = Query(default=""),
    dealer_code: str = Query(default=""),
    role: str = Query(default=""),
    limit: int = Query(default=500, ge=0, le=5000),
    offset: int = Query(default=0, ge=0),
    identity: AdminIdentity = Depends(_identity)
):
    _require(identity, SALES_ACTIVITY_ROLES)
    filters = []
    params = []
    
    if date:
        filters.append("DATE(ps.created_at) = %s")
        params.append(date)
    if dealer_code:
        filters.append("d.dealer_code ILIKE %s")
        params.append(f"%{dealer_code.strip()}%")
    if role:
        filters.append("f.role = %s")
        params.append(role)
        
    where_clause = f"WHERE {' AND '.join(filters)}" if filters else ""
    sql = f"""
        SELECT ps.id, ps.created_at, ps.ip_address, ps.user_agent, ps.revoked_at,
               f.name AS first_name, f.last_name, f.mobile_number, f.role,
               d.dealer_code, d.name AS dealer_name
        FROM public_sessions ps
        JOIN farmers f ON ps.farmer_id = f.id
        LEFT JOIN dealers d ON COALESCE(f.acquisition_dealer_id, f.preferred_dealer_id, f.verified_dealer_id) = d.id
        {where_clause}
        ORDER BY ps.created_at DESC
    """
    
    with connection() as conn:
        rows = conn.execute(sql if limit == 0 else sql + " LIMIT %s OFFSET %s", params if limit == 0 else params + [limit, offset]).fetchall()
        total = conn.execute(
            f"""SELECT COUNT(*) AS total FROM public_sessions ps
                JOIN farmers f ON ps.farmer_id = f.id
                LEFT JOIN dealers d ON COALESCE(f.acquisition_dealer_id, f.preferred_dealer_id, f.verified_dealer_id) = d.id
                {where_clause}""",
            params,
        ).fetchone()["total"]
        
    return {"items": rows, "total": total, "offset": offset, "limit": limit}
