'use client';

/* eslint-disable @typescript-eslint/no-explicit-any, @next/next/no-html-link-for-pages, react-hooks/set-state-in-effect -- Admin responses are capability-dependent JSON projections and refresh from server snapshots. */

import Image from 'next/image';
import FieldForce from './FieldForce';
import InspectionGallery from './InspectionGallery';
import AutomatedModelLab from './AutomatedModelLab';
import SystemArchitecture from './SystemArchitecture';
import Dealerships from './Dealerships';
import FarmerDetails from './FarmerDetails';
import LoginAudit from './LoginAudit';
import { AdminPager, AdminPageSize } from './AdminPagination';


import { FormEvent, useEffect, useMemo, useState } from 'react';

type Session = { configured: boolean; authenticated: boolean; auth_mode?: 'password' | 'microsoft' | 'none'; session: { email: string; name: string } | null };
type CapabilityMap = Record<string, boolean>;
type Product = { id: string; name: string; category: string; common_name: string | null; formulation: string | null; dose: string | null; use_benefits: string | null; packing: string | null; application_method: string | null; safety_information: string | null; image_path: string | null; source_page: number | null; catalogue_version: string; status: string; approval_status: string; version: number; crops: string[]; problems: string[]; price_per_pack: number | null; };
type Approval = { id: string; entity_key: string; requested_action: string; review_stage?: 'senior_manager' | 'final_publisher'; proposed_data: { product: Product; crops: string[] }; requested_at: string; requested_by_name?: string };
type PortalData = { overview?: any; products?: Product[]; options?: { categories: string[]; crops: string[] }; approvals?: Approval[]; inspections?: any[]; models?: any; employees?: any[]; employeeRoleOptions?: string[]; salesOfficers?: any; farmersAnalytics?: any; dealersAnalytics?: any; aiCostsAnalytics?: any; campaigns?: any[]; campaignsTotalSpend?: number };
type Section = 'overview' | 'catalogue' | 'campaigns' | 'approvals' | 'inspections' | 'gallery' | 'fieldforce' | 'models' | 'team' | 'architecture' | 'dealerships' | 'farmer_details' | 'login_audit';

const sections: Array<{ id: Section; label: string; icon: string; capability?: string }> = [
  { id: 'overview', label: 'Command centre', icon: '◈' }, { id: 'catalogue', label: 'Product catalogue', icon: '▦', capability: 'view_catalogue' },
  { id: 'campaigns', label: 'Marketing campaigns', icon: '★', capability: 'view_catalogue' },
  { id: 'approvals', label: 'Approvals', icon: '✓', capability: 'view_catalogue' }, { id: 'inspections', label: 'Inspections & S3', icon: '◌', capability: 'view_inspections' },
  { id: 'gallery', label: 'Photo gallery', icon: '▧', capability: 'view_inspections' },
  { id: 'fieldforce', label: 'Field force', icon: '⌖' },
  { id: 'dealerships', label: 'Dealerships', icon: '🏪', capability: 'view_dealers' },
  { id: 'farmer_details', label: 'Farmer Details', icon: '🌾', capability: 'view_sales_officer_activity' },
  { id: 'login_audit', label: 'Login Audit', icon: '🔒', capability: 'view_sales_officer_activity' },
  { id: 'models', label: 'AI diagnostic lab', icon: '⌁', capability: 'view_model_observability' },
  { id: 'team', label: 'Access & hierarchy', icon: '♙', capability: 'view_employee_access' }, { id: 'architecture', label: 'System architecture', icon: '◇' },
];
const freshProduct = (): Product => ({ id: '', name: '', category: '', common_name: '', formulation: '', dose: '', use_benefits: '', packing: '', application_method: '', safety_information: '', image_path: '', source_page: null, catalogue_version: 'Admin catalogue', status: 'active', approval_status: 'pending', version: 1, crops: [], problems: [], price_per_pack: null });
const displayDate = (value?: string) => value ? new Date(value).toLocaleString() : '—';
const bytes = (value: unknown) => { const n = Number(value || 0); return n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1048576).toFixed(1)} MB`; };
const roleLabel = (role: string) => role === 'expert_review_approver' ? 'inspection quality reviewer' : role.replaceAll('_', ' ');
const imageSource = (product: Product) => product.image_path?.startsWith('s3:') ? `/api/admin/product-images?key=${encodeURIComponent(product.image_path)}` : product.image_path || '';

type ApiErrorBody = { detail?: unknown; error?: unknown; message?: unknown };

function readableError(value: unknown): string {
  if (typeof value === 'string' && value.trim()) return value.trim();
  if (Array.isArray(value)) {
    const messages = value.map((item) => readableError(item)).filter(Boolean);
    return messages.join(' · ');
  }
  if (value && typeof value === 'object') {
    const record = value as Record<string, unknown>;
    if (typeof record.msg === 'string') {
      const location = Array.isArray(record.loc) ? record.loc.filter((part) => part !== 'body').join(' → ') : '';
      return location ? `${location}: ${record.msg}` : record.msg;
    }
    for (const key of ['detail', 'error', 'message']) {
      const message = readableError(record[key]);
      if (message) return message;
    }
  }
  return '';
}

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`/api/admin/portal/${path}`, { ...init, headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) }, cache: 'no-store' });
  const body = await response.json().catch(() => ({})) as ApiErrorBody;
  if (!response.ok) throw new Error(readableError(body) || 'The request could not be completed.');
  return body as T;
}
function Badge({ children, tone = 'slate' }: { children: React.ReactNode; tone?: 'green' | 'amber' | 'red' | 'slate' }) { return <span className={`admin-badge ${tone}`}>{children}</span>; }
function ProductStatus({ kind, value }: { kind: 'availability' | 'approval'; value: string }) {
  const approved = kind === 'approval' && value === 'approved';
  const active = kind === 'availability' && value === 'active';
  const label = kind === 'approval' ? (approved ? 'Approved' : 'Pending approval') : (active ? 'Active' : 'Inactive');
  return <span className={`admin-status-pill ${kind} ${value}`}><i aria-hidden="true" />{label}</span>;
}
function Metric({ label, value, note, tone = 'slate' }: { label: string; value: string | number; note: string; tone?: 'slate' | 'amber' | 'green' | 'red' }) { return <article className={`admin-metric ${tone}`}><p>{label}</p><strong>{value}</strong><small>{note}</small></article>; }
function BrandLogo({ gate = false }: { gate?: boolean }) { return <Image className={gate ? 'admin-gate-logo' : 'admin-brand-logo'} src="/clsl-logo.png" alt="Crop Life Science Limited" width={gate ? 118 : 54} height={gate ? 118 : 54} priority />; }

export default function AdminPortal() {
  const [session, setSession] = useState<Session | null>(null);
  const [identity, setIdentity] = useState<{ employee: { full_name: string; email: string; roles: string[] }; capabilities: CapabilityMap } | null>(null);
  const [data, setData] = useState<PortalData>({}); const [section, setSection] = useState<Section>('overview');
  const [editorOpen, setEditorOpen] = useState(false);
  const [selected, setSelected] = useState<Product | null>(null); const [draft, setDraft] = useState<Product>(freshProduct());
  const [notice, setNotice] = useState(''); const [error, setError] = useState(''); const [loading, setLoading] = useState(false);
  const [productStatusBusy, setProductStatusBusy] = useState('');
  const capabilities = identity?.capabilities || {}; const visibleSections = useMemo(() => sections.filter((item) => !item.capability || capabilities[item.capability]), [capabilities]);

  async function loadPortal() {
    setLoading(true); setError('');
    try {
      const me = await api<typeof identity>('me'); setIdentity(me);
      const safe = async <T,>(path: string) => api<T>(path).catch(() => undefined);
      const [overview, products, options, approvals, inspections, models, employees, salesOfficers, farmersAnalytics, dealersAnalytics, aiCostsAnalytics, campaigns] = await Promise.all([
        safe<any>('overview'), safe<{ items: Product[] }>('catalogue/products'), safe<{ categories: string[]; crops: string[] }>('catalogue/options'), safe<{ items: Approval[] }>('approvals'), safe<{ items: any[] }>('inspections'), safe<any>('models'), safe<{ items: any[]; assignable_role_codes?: string[] }>('access/employees'), safe<any>('sales-officers'),
        safe<any>('analytics/farmers'), safe<any>('analytics/dealers'), safe<any>('analytics/ai-costs'), safe<{ items: any[], total_spend: number }>('campaigns/analytics')
      ]);
      setData({ overview, products: products?.items, options, approvals: approvals?.items, inspections: inspections?.items, models, employees: employees?.items, employeeRoleOptions: employees?.assignable_role_codes, salesOfficers, farmersAnalytics, dealersAnalytics, aiCostsAnalytics, campaigns: campaigns?.items, campaignsTotalSpend: campaigns?.total_spend });
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Unable to load the private portal.'); } finally { setLoading(false); }
  }
  useEffect(() => { api<Session>('../auth/session').then((value) => { setSession(value); if (value.authenticated) void loadPortal(); }).catch(() => setSession({ configured: false, authenticated: false, session: null })); }, []);
  const updateDraft = (field: keyof Product, value: string | number | null) => setDraft((current) => ({ ...current, [field]: value }));
  const editProduct = (product: Product | null) => { setEditorOpen(true); setSelected(product); setDraft(product ? { ...product, crops: [...(product.crops || [])], problems: [...(product.problems || [])] } : freshProduct()); setSection('catalogue'); setError(''); };
  const toggleCrop = (crop: string) => setDraft((current) => ({ ...current, crops: current.crops.includes(crop) ? current.crops.filter((item) => item !== crop) : [...current.crops, crop] }));
  async function uploadProductImage(file: File) {
    if (!draft.id) throw new Error('Enter the stable product ID before uploading its package image.');
    const form = new FormData(); form.set('product_id', draft.id); form.set('image', file);
    const response = await fetch('/api/admin/product-images', { method: 'POST', body: form, cache: 'no-store' });
    const body = await response.json().catch(() => ({})) as { image_path?: string; error?: unknown; detail?: unknown };
    if (!response.ok || !body.image_path) throw new Error(readableError(body) || 'Product image upload failed.');
    updateDraft('image_path', body.image_path); setNotice('Package image uploaded privately. Submit the catalogue change to begin its approval workflow.');
  }
  async function submitChange(event: FormEvent) {
    event.preventDefault(); setError('');
    const product = {
      product_id: draft.id.trim(), name: draft.name.trim(), category: draft.category,
      common_name: draft.common_name || '', formulation: draft.formulation || '', dose: draft.dose || '',
      use_benefits: draft.use_benefits || '', packing: draft.packing || '', application_method: draft.application_method || '',
      safety_information: draft.safety_information || '', image_path: draft.image_path || '',
      source_page: draft.source_page || null, catalogue_version: draft.catalogue_version || 'Admin catalogue', status: draft.status,
      price_per_pack: draft.price_per_pack || null,
    };
    try { await api('catalogue/change-requests', { method: 'POST', body: JSON.stringify({ product, crops: draft.crops || [] }) }); setNotice('Submitted for approval. The farmer catalogue stays unchanged until the release workflow completes.'); setSelected(null); setEditorOpen(false); void loadPortal(); }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not submit the change.'); }
  }
  async function directProductStatus(product: Product, status: 'active' | 'inactive') {
    const verb = status === 'active' ? 'activate' : 'deactivate';
    if (!window.confirm(`${verb[0].toUpperCase()}${verb.slice(1)} ${product.name} immediately? This changes live farmer recommendations and will be recorded in the audit log.`)) return;
    setProductStatusBusy(product.id); setError('');
    try {
      await api(`catalogue/products/${product.id}/status`, { method: 'PATCH', body: JSON.stringify({ status, reason: 'Direct Super Administrator availability control' }) });
      setNotice(`${product.name} is now ${status}. The live catalogue and RAG have been refreshed.`);
      await loadPortal();
    } catch (reason) { setError(reason instanceof Error ? reason.message : `Could not ${verb} the product.`); }
    finally { setProductStatusBusy(''); }
  }
  async function decide(id: string, decision: 'approved' | 'rejected' | 'send_to_final_publisher') {
    const note = window.prompt(decision === 'approved' ? 'Final release note (optional)' : decision === 'send_to_final_publisher' ? 'Senior review note (optional)' : 'Reason for rejection') || '';
    if (decision === 'rejected' && !note.trim()) return;
    try { await api(`approvals/${id}/decision`, { method: 'POST', body: JSON.stringify({ decision, note }) }); setNotice(`Change ${decision.replaceAll('_', ' ')}.`); void loadPortal(); } catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not record the decision.'); }
  }
  async function removeInspection(id: string) {
    try {
    if (!window.confirm('Delete this inspection and all of its retained S3 image evidence permanently? This cannot be undone.')) return;
    const response = await fetch(`/api/admin/inspections/${id}`, { method: 'DELETE', cache: 'no-store' }); const body = await response.json().catch(() => ({})) as { error?: string };
    if (!response.ok) { setError(body.error || 'Inspection deletion failed.'); return; }
    setNotice('Inspection database record and retained S3 evidence were deleted.'); await loadPortal();
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Deletion failed; please retry.'); }
  }
  async function saveRoles(employeeId: string, roles: string[]) { try { await api(`access/employees/${employeeId}/roles`, { method: 'PUT', body: JSON.stringify({ roles }) }); setNotice('Employee roles updated.'); void loadPortal(); } catch (reason) { const message=reason instanceof Error ? reason.message : 'Could not save employee roles.'; setError(message); throw new Error(message); } }
  async function inviteEmployee(employeeId: string, roles: string[]) { try { const result = await api<{ name: string; email: string; email_sent: boolean; delivery_message: string; temporary_password?: string | null }>(`access/employees/${employeeId}/invite`, { method: 'POST', body: JSON.stringify({ roles }) }); setNotice(result.email_sent ? `Invitation emailed to ${result.email}.` : `Access created for ${result.email}; email delivery needs configuration.`); void loadPortal(); return result; } catch (reason) { const message=reason instanceof Error ? reason.message : 'Could not create portal access.'; setError(message); throw new Error(message); } }

  if (!session) return <main className="admin-loading">Opening Crop Life AI administration…</main>;
  if (!session.configured) return <SetupScreen />;
  if (!session.authenticated) return <SignInScreen mode={session.auth_mode} />;
  return <main className="admin-shell"><aside className="admin-sidebar"><a className="admin-brand" href="/"><BrandLogo /><span><strong>Crop Life AI</strong><small>CLSL OPERATIONS PORTAL</small></span></a><p className="admin-side-label">Control room</p><nav aria-label="Administration sections">{visibleSections.map((item) => <button key={item.id} className={section === item.id ? 'selected' : ''} onClick={() => { setSection(item.id); setSelected(null); setEditorOpen(false); }}><span>{item.icon}</span>{item.label}</button>)}</nav><div className="admin-sidebar-bottom"><p>Signed in as</p><strong>{identity?.employee.full_name || session.session?.name}</strong><small>{identity?.employee.email || session.session?.email}</small><div className="admin-role-list">{identity?.employee.roles.map((role) => <Badge key={role}>{roleLabel(role)}</Badge>)}</div><form action="/api/admin/auth/logout" method="post"><button className="admin-signout" type="submit">Sign out</button></form></div></aside><section className="admin-workspace"><header className="admin-topbar"><div><p className="admin-overline">Crop Life Science Limited</p><h1>{sections.find((item) => item.id === section)?.label}</h1></div><div className="admin-top-actions"><span className="admin-private"><i />Private operational data</span><button onClick={() => void loadPortal()} disabled={loading}>{loading ? 'Refreshing all data…' : 'Refresh all data'}</button></div></header>{(notice || error) && <div className={`admin-message ${error ? 'error' : 'success'}`} role="status" aria-live="polite"><span>{error ? '!' : '✓'}</span>{error || notice}<button aria-label="Dismiss message" onClick={() => { setNotice(''); setError(''); }}>×</button></div>}{section === 'overview' && <Overview data={data} productCount={data.products?.length || 0} onCatalogue={() => setSection('catalogue')} />}{section === 'catalogue' && <Catalogue editorOpen={editorOpen} onCancel={() => setEditorOpen(false)} products={data.products || []} options={data.options} draft={draft} selected={selected} canEdit={Boolean(capabilities.submit_catalogue_changes)} canDirectStatus={Boolean(capabilities.direct_catalogue_status)} statusBusy={productStatusBusy} onEdit={editProduct} onDirectStatus={directProductStatus} onChange={updateDraft} onCrop={toggleCrop} onImageUpload={uploadProductImage} onSubmit={submitChange} />}{section === 'campaigns' && <Campaigns items={data.campaigns || []} totalSpend={data.campaignsTotalSpend || 0} onRefresh={loadPortal} />}{section === 'approvals' && <Approvals items={data.approvals || []} canSenior={Boolean(capabilities.review_catalogue_changes)} canMap={Boolean(capabilities.decide_crop_mappings)} canSend={Boolean(capabilities.send_catalogue_changes_to_final_publisher)} canFinal={Boolean(capabilities.finalise_catalogue_release)} onDecision={decide} />}{section === 'inspections' && <Inspections items={data.inspections || []} canDelete={Boolean(capabilities.delete_inspections)} canReview={Boolean(capabilities.view_inspections)} onDelete={removeInspection} onReview={async (id, payload) => { await api(`inspections/${id}/expert-review`, { method: 'POST', body: JSON.stringify(payload) }); void loadPortal(); }} />}{section === 'gallery' && <InspectionGallery />}{section === 'fieldforce' && <FieldForce initialData={data.salesOfficers} canManage={Boolean(capabilities.manage_employee_roles)} />}{section === 'dealerships' && <Dealerships canManage={Boolean(capabilities.manage_dealers)} canManagePortalMobile={Boolean(capabilities.manage_dealer_portal_mobile)} canArchive={Boolean(capabilities.archive_dealers)} />}{section === 'farmer_details' && <FarmerDetails />}{section === 'login_audit' && <LoginAudit />}{section === 'models' && <AutomatedModelLab data={data.models} canControl={Boolean(capabilities.control_model_pipeline)} onRefresh={loadPortal} />}{section === 'team' && <Team items={data.employees || []} roleOptions={data.employeeRoleOptions || []} canManage={Boolean(capabilities.manage_employee_roles)} onSave={saveRoles} onInvite={inviteEmployee} />}{section === 'architecture' && <SystemArchitecture />}</section></main>;
}

function SetupScreen() { return <main className="admin-gate"><div className="admin-gate-card"><BrandLogo gate /><p className="admin-overline">Private operational portal</p><h1>Administration is not configured yet.</h1><p>Configure temporary HTTPS password access or Microsoft Entra sign-in on the private administration hostname.</p></div></main>; }
function SignInScreen({ mode }: { mode?: Session['auth_mode'] }) { return mode === 'password' ? <TemporaryPasswordSignIn /> : <main className="admin-gate"><div className="admin-gate-card"><BrandLogo gate /><p className="admin-overline">Crop Life Science Limited</p><h1>Crop Life AI operations portal</h1><p>Use your approved Crop Life Microsoft account. Your employee record and assigned role decide access.</p><a className="admin-login" href="/api/admin/auth/login">Continue with Microsoft <span>→</span></a></div></main>; }
function TemporaryPasswordSignIn() { const [username, setUsername] = useState(''); const [password, setPassword] = useState(''); const [error, setError] = useState(''); const [busy, setBusy] = useState(false); async function submit(event: FormEvent) { event.preventDefault(); setBusy(true); setError(''); const response = await fetch('/api/admin/auth/password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username, password }) }); const body = await response.json().catch(() => ({})) as ApiErrorBody; if (response.ok) window.location.reload(); else { setError(readableError(body) || 'Sign-in failed.'); setBusy(false); } } return <main className="admin-gate"><form className="admin-gate-card" onSubmit={submit}><BrandLogo gate /><p className="admin-overline">Secure employee access</p><h1>Crop Life AI operations portal</h1><p>Use your official Crop Life email and the password sent by the administrator.</p><label>Official email<input type="email" value={username} onChange={(event) => setUsername(event.target.value)} autoComplete="username" required /></label><label>Password<input type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="current-password" required /></label>{error && <p className="admin-form-error">{error}</p>}<button className="admin-login" disabled={busy}>{busy ? 'Signing in…' : 'Sign in →'}</button></form></main>; }

function Overview({ data, productCount, onCatalogue }: { data: PortalData; productCount: number; onCatalogue: () => void }) { 
  const overview = data.overview || {}; const inspection = overview.inspections_30d || {}; const product = overview.products || {}; const s3 = overview.private_s3 || {}; 
  const farmers = data.farmersAnalytics || {}; const costs = data.aiCostsAnalytics?.items || [];
  const totalCost = costs.reduce((acc: number, item: any) => acc + (Number(item.estimated_inr_cost) || 0), 0);
  return <div className="admin-content"><div className="admin-welcome"><div><p className="admin-overline">Live governance status</p><h2>One approved catalogue. Controlled field advice.</h2><p>The farmer product screen, Crop Life AI catalogue context and crop inspection all read the same released PostgreSQL product records.</p></div><button onClick={onCatalogue}>Open catalogue →</button></div><div className="admin-metric-grid"><Metric label="Registered farmers" value={farmers.total_farmers || 0} note="Total acquisitions" /><Metric label="Estimated AI Cost (INR)" value={`₹${totalCost.toFixed(2)}`} note="Across all AI requests" tone="amber" /><Metric label="Released products" value={product.approved ?? productCount} note={`${product.pending || 0} awaiting approval`} tone="green" /><Metric label="Inspections (30 days)" value={inspection.total || 0} note={`${inspection.completed || 0} completed`} /></div><div className="admin-two-column"><article className="admin-panel"><p className="admin-overline">Data health</p><h3>Inspection archive</h3><p>{inspection.s3_stored || 0} completed records have evidence retained in private S3. Any storage exception remains visible for review.</p></article><article className="admin-panel"><p className="admin-overline">Release path</p><h3>Controlled publishing</h3><p>Manager proposes → Senior manager validates → Super Administrator releases. Only the final release updates the live farmer RAG.</p></article></div></div>; }

function Catalogue({ editorOpen, onCancel, products, options, draft, selected, canEdit, canDirectStatus, statusBusy, onEdit, onDirectStatus, onChange, onCrop, onImageUpload, onSubmit }: { editorOpen: boolean; onCancel: () => void; products: Product[]; options?: { categories: string[]; crops: string[] }; draft: Product; selected: Product | null; canEdit: boolean; canDirectStatus: boolean; statusBusy: string; onEdit: (product: Product | null) => void; onDirectStatus: (product: Product, status: 'active' | 'inactive') => Promise<void>; onChange: (field: keyof Product, value: string | number | null) => void; onCrop: (crop: string) => void; onImageUpload: (file: File) => Promise<void>; onSubmit: (event: FormEvent) => void }) {
  const [query, setQuery] = useState(''); const [status, setStatus] = useState('all'); const [page,setPage]=useState(1); const [pageSize,setPageSize]=useState<AdminPageSize>(25); const visible = products.filter((product) => (status === 'all' || product.status === status) && `${product.id} ${product.name} ${product.category} ${(product.crops || []).join(' ')}`.toLowerCase().includes(query.toLowerCase())); const paged=pageSize===0?visible:visible.slice((page-1)*pageSize,page*pageSize);
  useEffect(()=>setPage(1),[query,status,pageSize]);
  if (editorOpen && canEdit) return <div className="admin-content"><CatalogueEditor draft={draft} options={options} canEdit={canEdit} onChange={onChange} onCrop={onCrop} onCancel={onCancel} onImageUpload={onImageUpload} onSubmit={onSubmit} isNew={!selected} /></div>;
  return <div className="admin-content"><div className="admin-list-toolbar"><div><p className="admin-overline">Controlled product master</p><h2>{products.length} catalogue products</h2><p>Only products that are both active and finally approved can be shown to farmers or Gemini.</p></div>{canEdit && <button className="admin-primary" onClick={() => onEdit(null)}>+ Add product</button>}</div><div className="admin-catalogue-filters"><label className="admin-search"><span>⌕</span><input placeholder="Search product, category or crop" value={query} onChange={(event) => setQuery(event.target.value)} /></label><label className="admin-status-filter"><span>Farmer availability</span><select value={status} onChange={(event) => setStatus(event.target.value)}><option value="all">All products</option><option value="active">Active / recommendable after approval</option><option value="inactive">Inactive / discontinued</option></select></label></div><div className="admin-product-grid">{paged.map((product) => <article key={product.id} className="admin-product-card"><div className="admin-product-image">{product.image_path ? <img src={imageSource(product)} alt={`${product.name} package`} /> : <span>CLSL</span>}</div><div className="admin-product-title"><div><small>{product.category}</small><h3>{product.name}</h3><p>{product.common_name || product.formulation || 'Details pending'}</p></div><div className="admin-product-status"><ProductStatus kind="availability" value={product.status} /><ProductStatus kind="approval" value={product.approval_status} /></div></div><dl><div><dt>Dose</dt><dd>{product.dose || 'Not recorded'}</dd></div><div><dt>Approved crops</dt><dd className="admin-crop-chips">{product.crops?.slice(0, 5).map((crop) => <span key={crop}>{crop}</span>)}</dd></div></dl>{canEdit && <button className="admin-secondary" onClick={() => onEdit(product)}>Edit details / image →</button>}{canEdit && (canDirectStatus ? <button className={`admin-secondary ${product.status === 'active' ? 'danger' : ''}`} disabled={statusBusy === product.id} onClick={() => void onDirectStatus(product, product.status === 'active' ? 'inactive' : 'active')}>{statusBusy === product.id ? 'Applying…' : product.status === 'active' ? 'Deactivate now' : 'Activate now'}</button> : <button className="admin-secondary" onClick={() => onEdit({ ...product, status: product.status === 'active' ? 'inactive' : 'active' })}>{product.status === 'active' ? 'Propose deactivation' : 'Propose activation'}</button>)}</article>)}</div>{!visible.length && <p className="admin-empty">No product record matches this filter.</p>}{visible.length>0&&<AdminPager page={page} pageSize={pageSize} total={visible.length} shown={paged.length} onPage={setPage} onPageSize={setPageSize}/>}</div>;
}
function CatalogueEditor({ draft, options, canEdit, onChange, onCrop, onCancel, onImageUpload, onSubmit, isNew }: { draft: Product; options?: { categories: string[]; crops: string[] }; canEdit: boolean; onChange: (field: keyof Product, value: string | number | null) => void; onCrop: (crop: string) => void; onCancel: () => void; onImageUpload: (file: File) => Promise<void>; onSubmit: (event: FormEvent) => void; isNew: boolean }) {
  const [uploading, setUploading] = useState(false); const [uploadError, setUploadError] = useState(''); const upload = async (file?: File) => { if (!file) return; setUploading(true); setUploadError(''); try { await onImageUpload(file); } catch (reason) { setUploadError(reason instanceof Error ? reason.message : 'Image upload failed.'); } finally { setUploading(false); } };
  return <form onSubmit={onSubmit} className="admin-editor"><header><div><button type="button" className="admin-back" onClick={onCancel}>← Catalogue</button><p className="admin-overline">{isNew ? 'New product proposal' : 'Controlled product change'}</p><h2>{isNew ? 'Prepare product record' : `Propose changes to ${draft.name}`}</h2><p>Active/inactive status and package images are also approval-controlled. Nothing changes for farmers until final release.</p></div>{draft.image_path && <div className="admin-editor-image"><img src={imageSource(draft)} alt="Product package preview" /></div>}</header><fieldset disabled={!canEdit}><div className="admin-form-grid"><Field label="Product ID" value={draft.id} onChange={(value) => onChange('id', value)} required disabled={!isNew} hint="Stable code, e.g. CLSL-001" /><Field label="Product name" value={draft.name} onChange={(value) => onChange('name', value)} required /><label><span>Category *</span><select value={draft.category} required onChange={(event) => onChange('category', event.target.value)}><option value="">Select category</option>{options?.categories.map((category) => <option key={category}>{category}</option>)}</select></label><label><span>Farmer availability *</span><select value={draft.status} onChange={(event) => onChange('status', event.target.value)}><option value="active">Active — can be recommended after approval</option><option value="inactive">Inactive — discontinued / do not recommend</option></select><small>Inactive products remain managed here but are excluded from RAG.</small></label><label><span>Package image</span><input type="file" accept="image/jpeg,image/png,image/webp" disabled={!draft.id || uploading} onChange={(event) => void upload(event.target.files?.[0])} /><small>{!draft.id ? 'Enter the product ID first.' : uploading ? 'Uploading securely…' : 'JPG, PNG or WebP, maximum 5 MB. Stored privately in S3.'}</small>{uploadError && <small className="admin-form-error">{uploadError}</small>}</label><Field label="Common name / active ingredient" value={draft.common_name || ''} onChange={(value) => onChange('common_name', value)} /><Field label="Formulation" value={draft.formulation || ''} onChange={(value) => onChange('formulation', value)} /><Field label="Dose / application rate" value={draft.dose || ''} onChange={(value) => onChange('dose', value)} /><TextArea label="Uses / benefits" value={draft.use_benefits || ''} onChange={(value) => onChange('use_benefits', value)} /><Field label="Packing" value={draft.packing || ''} onChange={(value) => onChange('packing', value)} /><Field label="Price per pack (₹)" type="number" value={draft.price_per_pack?.toString() || ''} onChange={(value) => onChange('price_per_pack', value ? Number(value) : null)} /><TextArea label="Application method" value={draft.application_method || ''} onChange={(value) => onChange('application_method', value)} /><TextArea label="Safety information" value={draft.safety_information || ''} onChange={(value) => onChange('safety_information', value)} /><Field label="Catalogue page" type="number" value={draft.source_page?.toString() || ''} onChange={(value) => onChange('source_page', value ? Number(value) : null)} /></div><section className="admin-crop-selector"><div><p className="admin-overline">Crop approval mapping</p><h3>Select approved crops</h3><p>Only selected mappings are eligible after final release.</p></div><div className="admin-crop-options">{options?.crops.map((crop) => <label key={crop}><input type="checkbox" checked={draft.crops.includes(crop)} onChange={() => onCrop(crop)} /><span>{crop}</span></label>)}</div></section></fieldset><footer><button type="button" className="admin-secondary" onClick={onCancel}>Cancel</button>{canEdit && <button className="admin-primary" type="submit" disabled={uploading}>Submit for approval →</button>}</footer></form>;
}
function Field({ label, value, onChange, type = 'text', required, disabled, hint }: { label: string; value: string; onChange: (value: string) => void; type?: string; required?: boolean; disabled?: boolean; hint?: string }) { return <label><span>{label}{required ? ' *' : ''}</span><input type={type} value={value} required={required} disabled={disabled} onChange={(event) => onChange(event.target.value)} />{hint && <small>{hint}</small>}</label>; }
function TextArea({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) { return <label className="admin-wide"><span>{label}</span><textarea value={value} onChange={(event) => onChange(event.target.value)} rows={3} /></label>; }

function Approvals({ items, canSenior, canMap, canSend, canFinal, onDecision }: { items: Approval[]; canSenior: boolean; canMap: boolean; canSend: boolean; canFinal: boolean; onDecision: (id: string, decision: 'approved' | 'rejected' | 'send_to_final_publisher') => void }) { return <div className="admin-content"><div className="admin-list-toolbar"><div><p className="admin-overline">Controlled publishing queue</p><h2>{items.length} pending catalogue approvals</h2><p>Only final release changes the live farmer catalogue and RAG.</p></div><Badge tone={items.length ? 'amber' : 'green'}>{items.length ? 'Review needed' : 'All clear'}</Badge></div><div className="admin-approval-list">{items.map((item) => { const product = item.proposed_data.product; const final = item.review_stage === 'final_publisher'; const canAct = final ? canFinal : canSenior; const mapBlocked = Boolean(item.proposed_data.crops?.length && !canMap && !final); return <article key={item.id}><header><div><small>{item.requested_action.replaceAll('_', ' ')}</small><h3>{product.name} <span>({item.entity_key})</span></h3><p>Submitted by {item.requested_by_name || 'an authorised employee'} · {displayDate(item.requested_at)}</p></div><Badge tone={final ? 'amber' : 'slate'}>{final ? 'Final release queue' : 'Senior review'}</Badge></header><div className="admin-change-summary"><div><span>Category / formulation</span><b>{product.category} · {product.formulation || product.common_name || '—'}</b></div><div><span>Uses</span><b>{product.use_benefits || '—'}</b></div><div><span>Safety / application</span><b>{product.safety_information || '—'} · {product.application_method || '—'}</b></div><div><span>Package image</span>{product.image_path ? <img src={imageSource(product)} alt="Proposed package image" style={{ maxHeight: 180, maxWidth: 180, objectFit: 'contain' }} /> : <b>No image</b>}</div><div><span>Availability</span><b>{product.status}</b></div><div><span>Dose</span><b>{product.dose || '—'}</b></div><div><span>Approved crops</span><b>{item.proposed_data.crops?.join(', ') || 'None selected'}</b></div></div>{canAct ? <footer><button className="admin-secondary danger" onClick={() => onDecision(item.id, 'rejected')}>Reject</button>{!final && canSend && <button className="admin-primary" disabled={mapBlocked} onClick={() => onDecision(item.id, 'send_to_final_publisher')}>Validate & send to final release →</button>}{final && <button className="admin-primary" onClick={() => onDecision(item.id, 'approved')}>Approve & publish live</button>}</footer> : <footer><p>{final ? 'Awaiting protected final release.' : 'Awaiting Senior Catalogue Manager review.'}</p></footer>}</article>; })}</div>{!items.length && <p className="admin-empty">There are no catalogue changes awaiting approval.</p>}</div>; }

function Inspections({ items, canDelete, canReview, onDelete, onReview }: { items: any[]; canDelete: boolean; canReview: boolean; onDelete: (id: string) => void; onReview: (id: string, payload: any) => Promise<void> }) {
  const [selected, setSelected] = useState<any | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState<AdminPageSize>(25);
  const visibleItems = pageSize === 0 ? items : items.slice((page - 1) * pageSize, page * pageSize);
  useEffect(() => { if (selected && !items.some((item) => item.id === selected.id)) setSelected(null); }, [items, selected]);
  if (selected) return <InspectionDetail item={selected} close={() => setSelected(null)} canDelete={canDelete} canReview={canReview} onDelete={() => onDelete(selected.id)} onReview={(payload) => onReview(selected.id, payload)} />;
  return <div className="admin-content"><div className="admin-list-toolbar"><div><p className="admin-overline">Private archive controls</p><h2>Crop inspection archive</h2><p>Inspect the photos, live diagnosis, three-model outputs and catalogue result. Cases enter the model-quality pipeline automatically; authorised quality reviewers can remove unsuitable cases.</p></div><Badge tone="green">Automatic quality flow</Badge></div><div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Inspection / employee</th><th>Live diagnosis</th><th>Automatic dataset state</th><th>Private S3 archive</th><th>Action</th></tr></thead><tbody>{visibleItems.map((item) => <tr key={item.id}><td><b>{item.employee_name || 'General / anonymous user'}</b><small>{item.employee_code || String(item.id).slice(0, 8)} · {displayDate(item.created_at)}</small><small>{item.location_text || 'Location not supplied'}</small></td><td><b>{item.detected_crop || item.farmer_crop_text || 'Crop not supplied'}</b><small>{item.probable_issue || 'No successful live assessment'}</small></td><td><Badge tone={item.training_eligible ? 'green' : item.dataset_quality_status === 'excluded' ? 'red' : 'amber'}>{String(item.dataset_quality_status || 'awaiting_models').replaceAll('_', ' ')}</Badge><small>{item.consensus_status ? `${String(item.consensus_status).replaceAll('_', ' ')} · ${item.agreement_count || 0}/3` : 'Waiting for model comparison'}</small></td><td><b>{item.retained_images || 0} files · {bytes(item.retained_bytes)}</b><small>{item.image_storage_status}</small></td><td><button className="admin-secondary" onClick={() => setSelected(item)}>Inspect case →</button></td></tr>)}</tbody></table><AdminPager page={page} pageSize={pageSize} total={items.length} shown={visibleItems.length} onPage={setPage} onPageSize={(value)=>{setPage(1);setPageSize(value)}}/></div>{!items.length && <p className="admin-empty">No persisted inspections are available yet.</p>}</div>;
}

function InspectionDetail({ item, close, canDelete, canReview, onDelete, onReview }: { item: any; close: () => void; canDelete: boolean; canReview: boolean; onDelete: () => void; onReview: (payload: any) => Promise<void> }) {
  const orders = Array.isArray(item.image_orders) ? item.image_orders : [];
  const predictions = Array.isArray(item.model_predictions) ? item.model_predictions : [];
  const [reviewStatus, setReviewStatus] = useState('Correct');
  const [trainingEligible, setTrainingEligible] = useState(true);
  const [reviewNotes, setReviewNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function handleReview(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      await onReview({ status: reviewStatus, training_eligible: trainingEligible, review_notes: reviewNotes });
      close();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Review failed');
    } finally {
      setSubmitting(false);
    }
  }

  return <div className="admin-content"><button className="admin-back" onClick={close}>← All inspections</button><div className="admin-case-head"><div><p className="admin-overline">Private inspection case</p><h2>{item.detected_crop || item.farmer_crop_text || 'Crop inspection'} <span>· {String(item.id).slice(0, 8)}</span></h2><p>{displayDate(item.created_at)} · {item.location_text || 'Location not supplied'}</p></div><Badge tone={item.training_eligible ? 'green' : 'amber'}>{String(item.dataset_quality_status || 'awaiting_models').replaceAll('_', ' ')}</Badge></div><div className="admin-case-grid"><article className="admin-panel"><p className="admin-overline">Live farmer assessment</p><h3>{item.probable_issue || 'No completed assessment'}</h3><dl className="admin-case-facts"><div><dt>Issue type</dt><dd>{item.issue_type || '—'}</dd></div><div><dt>Severity</dt><dd>{item.severity || '—'}</dd></div><div><dt>Confidence</dt><dd>{item.confidence != null ? `${Math.round(Number(item.confidence) * 100)}%` : '—'}</dd></div></dl><p>{item.summary || 'A successful provider result was not recorded.'}</p><div className="admin-next-action"><b>Recommended next action</b><p>{item.recommended_next_action || 'Inspect the retained crop evidence.'}</p></div></article><article className="admin-panel"><p className="admin-overline">Approved catalogue output</p><h3>{(item.suggested_product_ids || []).length ? 'Products shown to the farmer' : 'No product shown'}</h3><div className="admin-role-list">{(item.suggested_product_ids || []).map((id: string) => <Badge key={id} tone="green">{id}</Badge>)}</div><p>Catalogue matches use active, approved PostgreSQL records—not generated product names.</p></article></div><section className="admin-panel"><header><div><p className="admin-overline">Independent comparison</p><h3>Gemma · Flash-Lite · Qwen</h3><p>No expert approval is required. A qualified 2-of-3 majority enters the Qwen fine-tuning dataset automatically.</p></div><Badge tone={Number(item.agreement_count) >= 2 ? 'green' : 'amber'}>{Number(item.agreement_count) >= 2 ? `${item.agreement_count}/3 majority` : 'Comparison pending'}</Badge></header><div className="admin-case-grid">{predictions.map((prediction: any) => <article className="admin-next-action" key={`${prediction.provider}-${prediction.model}`}><b>{prediction.provider === 'gemini' ? 'Gemini Flash-Lite' : String(prediction.provider || '').toUpperCase()}</b><h3>{prediction.issue_name || 'No conclusive issue'}</h3><p>{String(prediction.issue_type || 'unknown').replaceAll('_', ' ')} · {prediction.confidence != null ? `${Math.round(Number(prediction.confidence) * 100)}%` : 'no confidence'} · {prediction.latency_ms ? `${(Number(prediction.latency_ms) / 1000).toFixed(1)}s` : '—'}</p></article>)}</div></section>
  
  {canReview && <section className="admin-panel"><form onSubmit={handleReview}>
    <header><div><p className="admin-overline">Quality review</p><h3>Expert Ground Truth</h3></div><Badge tone="slate">Human Feedback</Badge></header>
    <div className="admin-form-grid">
      <label><span>Status</span><select value={reviewStatus} onChange={(e) => setReviewStatus(e.target.value)}><option value="Correct">Correct</option><option value="Partially Correct">Partially Correct</option><option value="Incorrect">Incorrect</option><option value="Reject">Reject (Garbage / Not crop)</option></select></label>
      <label className="admin-wide"><span>Eligible for AI Training (Qwen Fine-Tuning)</span><input type="checkbox" checked={trainingEligible} onChange={(e) => setTrainingEligible(e.target.checked)} style={{width: 'auto', marginLeft: 16}} /></label>
      <TextArea label="Expert Notes" value={reviewNotes} onChange={setReviewNotes} />
    </div>
    <footer><button className="admin-primary" disabled={submitting}>{submitting ? 'Submitting...' : 'Submit Expert Review'}</button></footer>
  </form></section>}
  
  <section className="admin-private-gallery"><header><div><p className="admin-overline">Private S3 evidence</p><h3>{orders.length} retained photo{orders.length === 1 ? '' : 's'}</h3><p>Quality reviewers should delete only clearly irrelevant, unusable or incorrectly labelled cases. Deletion also removes the case from the automatic dataset.</p></div>{canDelete && <button className="admin-secondary danger" onClick={onDelete}>Remove unsuitable case & S3 photos</button>}</header>{orders.length ? <div className="admin-photo-grid">{orders.map((order: number) => <figure key={order}><img src={`/api/admin/inspection-images/${item.id}/${order}`} alt={`Private crop evidence ${order}`} /><figcaption>Evidence photo {order} · private S3</figcaption></figure>)}</div> : <p className="admin-empty">No retained S3 photo is available.</p>}</section></div>;
}
type InvitationResult = { name: string; email: string; email_sent: boolean; delivery_message: string; temporary_password?: string | null };
const roleProfiles: Record<string, string[]> = {
  manager: ['field_employee', 'manager', 'catalogue_manager'],
  senior_manager: ['field_employee', 'senior_catalogue_manager', 'mapping_approver', 'expert_review_approver'],
  managing_director: ['field_employee', 'managing_director', 'product_approver', 'mapping_approver'],
  quality_reviewer: ['field_employee', 'expert_review_approver'],
};

function Team({ items, roleOptions, canManage, onSave, onInvite }: {
  items: any[]; roleOptions: string[]; canManage: boolean;
  onSave: (employeeId: string, roles: string[]) => Promise<void>;
  onInvite: (employeeId: string, roles: string[]) => Promise<InvitationResult>;
}) {
  const [query, setQuery] = useState(''); const [hrState, setHrState] = useState('all');
  const [selected, setSelected] = useState<any | null>(null); const [roles, setRoles] = useState<string[]>([]);
  const [profile, setProfile] = useState('custom'); const [saving, setSaving] = useState(false); const [inviting, setInviting] = useState(false);
  const [invitation, setInvitation] = useState<InvitationResult | null>(null);
  const [page,setPage]=useState(1); const [pageSize,setPageSize]=useState<AdminPageSize>(25);
  const visible = items.filter((employee) => (hrState === 'all' || employee.hr_sync_state === hrState)
    && `${employee.full_name} ${employee.employee_code} ${employee.office_email || ''} ${employee.department || ''} ${employee.location || ''}`.toLowerCase().includes(query.toLowerCase()));
  const paged=pageSize===0?visible:visible.slice((page-1)*pageSize,page*pageSize);
  useEffect(()=>setPage(1),[query,hrState,pageSize]);
  const openEditor = (employee: any) => {
    setSelected(employee); setRoles(Array.isArray(employee.roles) ? employee.roles.filter((role: string) => role !== 'super_admin') : []);
    setProfile('custom'); setInvitation(null);
  };
  const applyProfile = (value: string) => { setProfile(value); if (roleProfiles[value]) setRoles(roleProfiles[value].filter((role) => roleOptions.includes(role))); };
  const toggle = (role: string) => { setProfile('custom'); setRoles((current) => current.includes(role) ? current.filter((item) => item !== role) : [...current, role]); };
  const save = async () => { if (!selected) return; setSaving(true); try { await onSave(selected.id, roles); setSelected(null); } catch { /* Portal banner shows the reason. */ } finally { setSaving(false); } };
  const invite = async () => { if (!selected) return; setInviting(true); setInvitation(null); try { setInvitation(await onInvite(selected.id, roles)); } catch { /* Portal banner shows the reason. */ } finally { setInviting(false); } };
  return <div className="admin-content">
    <div className="admin-list-toolbar"><div><p className="admin-overline">Employee directory & access hierarchy</p><h2>{items.length} official employee records</h2><p>Select an employee by official email, choose a responsibility profile and send access. No duplicate employee or dummy identity is created.</p></div><Badge tone={canManage ? 'green' : 'slate'}>{canManage ? 'Super Administrator' : 'Read-only directory'}</Badge></div>
    <div className="admin-metric-grid admin-team-metrics"><Metric label="Employees" value={items.length} note="Official employee master" tone="green" /><Metric label="Portal access" value={items.filter((employee) => employee.portal_access_active).length} note="Email/password accounts" /><Metric label="Updated" value={items.filter((employee) => employee.hr_sync_state === 'updated').length} note="Official HR fields changed" tone="amber" /><Metric label="Inactive / left" value={items.filter((employee) => employee.hr_sync_state === 'inactive').length} note="Access automatically blocked" /></div>
    {selected && <section className="admin-role-editor"><header><div><p className="admin-overline">Assign profile and invite by email</p><h3>{selected.full_name} <span>· {selected.employee_code}</span></h3><p>{selected.office_email || selected.microsoft_upn || 'No official email recorded'} · Super Administrator access remains protected.</p></div><button className="admin-secondary" onClick={() => { setSelected(null); setInvitation(null); }}>Cancel</button></header>
      <label className="admin-access-profile"><span>Responsibility profile</span><select value={profile} onChange={(event) => applyProfile(event.target.value)}><option value="custom">Custom permissions</option><option value="manager">Manager — prepare and edit catalogue proposals</option><option value="senior_manager">Senior Manager — validate mappings and inspect data</option><option value="managing_director">Managing Director — executive review and approval</option><option value="quality_reviewer">Inspection Quality Reviewer — inspect and remove unsuitable cases</option></select><small>You can adjust individual permissions below. Model-quality cases do not require human approval; this reviewer handles exceptions.</small></label>
      <div className="admin-role-options">{roleOptions.map((role) => <label key={role}><input type="checkbox" checked={roles.includes(role)} onChange={() => toggle(role)} /><span>{roleLabel(role)}</span></label>)}</div>
      {invitation && <div className={`admin-invitation-result ${invitation.email_sent ? 'sent' : 'manual'}`}><b>{invitation.email_sent ? `Invitation sent to ${invitation.email}` : `Access created for ${invitation.email}`}</b><p>{invitation.delivery_message}</p>{invitation.temporary_password && <><small>Temporary password — shown only in this response</small><div><input readOnly value={invitation.temporary_password} onFocus={(event) => event.target.select()} /><button className="admin-secondary" type="button" onClick={() => void navigator.clipboard.writeText(invitation.temporary_password || '')}>Copy password</button></div></>}</div>}
      <footer><button className="admin-secondary" disabled={saving || inviting} onClick={() => void save()}>{saving ? 'Saving…' : 'Save roles only'}</button><button className="admin-primary" disabled={saving || inviting || !roles.length || !(selected.office_email || selected.microsoft_upn)} onClick={() => void invite()}>{inviting ? 'Creating secure access…' : selected.portal_access_active ? 'Reset password & resend access' : 'Create account & send password'}</button></footer>
    </section>}
    <div className="admin-catalogue-filters"><label className="admin-search"><span>⌕</span><input placeholder="Search employee, email, code, department or location" value={query} onChange={(event) => setQuery(event.target.value)} /></label><label className="admin-status-filter">HR status<select value={hrState} onChange={(event) => setHrState(event.target.value)}><option value="all">All employees</option><option value="new">New</option><option value="existing">Existing</option><option value="updated">Updated</option><option value="inactive">Inactive / left</option></select></label></div>
    <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Official employee</th><th>Organisation</th><th>Reporting manager</th><th>Assigned roles</th><th>Portal access</th>{canManage && <th>Action</th>}</tr></thead><tbody>{paged.map((employee) => <tr key={employee.id}><td><b>{employee.full_name}</b><small>{employee.employee_code} · {employee.office_email || employee.microsoft_upn || 'No work email recorded'}</small></td><td>{employee.department || '—'}<small>{employee.designation || employee.location || '—'}</small></td><td>{employee.reporting_manager_name || 'Not recorded'}</td><td><div className="admin-role-list">{(employee.roles || []).length ? (employee.roles || []).map((role: string) => <Badge key={role}>{roleLabel(role)}</Badge>) : <span className="admin-no-role">No admin role</span>}</div></td><td><Badge tone={employee.portal_access_active ? 'green' : 'slate'}>{employee.portal_access_active ? 'Access issued' : 'Not invited'}</Badge><small>{employee.portal_last_login_at ? `Last login ${displayDate(employee.portal_last_login_at)}` : employee.portal_invited_at ? `Invited ${displayDate(employee.portal_invited_at)}` : '—'}</small></td>{canManage && <td><button className="admin-secondary" onClick={() => openEditor(employee)}>Set profile / invite</button></td>}</tr>)}</tbody></table><AdminPager page={page} pageSize={pageSize} total={visible.length} shown={paged.length} onPage={setPage} onPageSize={setPageSize}/></div>
    {!visible.length && <p className="admin-empty">No employee matches this search.</p>}
  </div>;
}

function Campaigns({ items, totalSpend, onRefresh }: { items: any[]; totalSpend: number; onRefresh: () => void }) {
  const [name, setName] = useState('');
  const [discountValue, setDiscountValue] = useState('10');
  const [discountType, setDiscountType] = useState('percentage');
  const [bulkCount, setBulkCount] = useState('100');
  const [selectedCampaign, setSelectedCampaign] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const start_date = new Date().toISOString();
      await api('campaigns', { method: 'POST', body: JSON.stringify({ name, discount_type: discountType, discount_value: Number(discountValue), start_date, status: 'active' }) });
      setName('');
      onRefresh();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Error creating campaign');
    } finally {
      setBusy(false);
    }
  }

  async function toggleStatus(id: string, currentStatus: string) {
    const newStatus = currentStatus === 'active' ? 'paused' : 'active';
    try {
      await api(`campaigns/${id}/status`, { method: 'PUT', body: JSON.stringify({ status: newStatus }) });
      onRefresh();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Error updating status');
    }
  }

  async function generateBulk(e: FormEvent) {
    e.preventDefault();
    if (!selectedCampaign) return alert('Select a campaign first');
    setBusy(true);
    try {
      const res = await api<{generated_count: number}>(`campaigns/${selectedCampaign}/bulk-generate`, { method: 'POST', body: JSON.stringify({ count: Number(bulkCount) }) });
      alert(`Successfully generated ${res.generated_count} coupons!`);
      onRefresh();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Error generating coupons');
    } finally {
      setBusy(false);
    }
  }

  const activeCount = items.filter(i => i.status === 'active').length;
  const totalIssued = items.reduce((acc, curr) => acc + (curr.total_issued || 0), 0);
  const totalRedeemed = items.reduce((acc, curr) => acc + (curr.total_redeemed || 0), 0);

  return (
    <div className="admin-content">
      <div className="admin-list-toolbar">
        <div><p className="admin-overline">Farmer acquisition</p><h2>Marketing Campaigns</h2></div>
      </div>
      
      <div className="admin-metric-grid" style={{ marginBottom: '24px' }}>
        <Metric label="Total Spend (INR)" value={`₹${Number(totalSpend || 0).toFixed(2)}`} note="Across all redemptions" tone={Number(totalSpend || 0) > 50000 ? "red" : "amber"} />
        <Metric label="Coupons Redeemed" value={totalRedeemed} note={`${totalIssued} total issued`} tone="green" />
        <Metric label="Active Campaigns" value={activeCount} note="Currently running" tone="slate" />
      </div>

      <div className="admin-two-column">
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <form className="admin-panel" onSubmit={submit}>
            <h3>Create New Campaign</h3>
            <label>Campaign Name<input value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Welcome" required minLength={2} /></label>
            <div style={{ display: 'flex', gap: '16px' }}>
              <label style={{ flex: 1 }}>Discount Type<select value={discountType} onChange={e=>setDiscountType(e.target.value)}><option value="percentage">Percentage (%)</option><option value="fixed_amount">Fixed Amount (₹)</option></select></label>
              <label style={{ flex: 1 }}>Value<input type="number" min="1" step="0.5" value={discountValue} onChange={e=>setDiscountValue(e.target.value)} required /></label>
            </div>
            <button className="admin-primary" disabled={busy} style={{ marginTop: '16px' }}>{busy ? 'Saving...' : 'Create Campaign'}</button>
          </form>
          
          <form className="admin-panel" onSubmit={generateBulk}>
            <h3>Bulk Generate Coupons</h3>
            <p className="admin-side-label" style={{ marginBottom: '16px' }}>Generate unique 7-character secure codes for an existing campaign.</p>
            <label>Select Campaign
              <select value={selectedCampaign} onChange={e=>setSelectedCampaign(e.target.value)} required>
                <option value="">-- Choose Campaign --</option>
                {items.map(c => <option key={c.campaign_id} value={c.campaign_id}>{c.name}</option>)}
              </select>
            </label>
            <label>Number of Coupons<input type="number" min="1" max="5000" value={bulkCount} onChange={e=>setBulkCount(e.target.value)} required /></label>
            <button className="admin-secondary" disabled={busy || !selectedCampaign} style={{ marginTop: '16px' }}>{busy ? 'Generating...' : 'Generate Codes'}</button>
          </form>
        </div>

        <div className="admin-panel">
          <h3>Campaign Analytics</h3>
          <div className="admin-table-wrap">
            <table className="admin-table">
              <thead><tr><th>Campaign</th><th>Stats</th><th>Spend</th><th>Status / Action</th></tr></thead>
              <tbody>
                {items.map(c => (
                  <tr key={c.campaign_id}>
                    <td><b>{c.name}</b><small>{c.discount_value}{c.discount_type === 'percentage' ? '%' : '₹'} off</small></td>
                    <td><b>{c.total_redeemed || 0} availed</b><small>{(c.total_issued || 0) - (c.total_redeemed || 0)} remaining</small></td>
                    <td><b>₹{Number(c.total_spend || 0).toFixed(2)}</b></td>
                    <td>
                      <Badge tone={c.status === 'active' ? 'green' : 'slate'}>{c.status}</Badge>
                      <button className="admin-secondary" onClick={() => toggleStatus(c.campaign_id, c.status)} style={{ marginTop: '8px', padding: '4px 8px', fontSize: '11px' }}>
                        {c.status === 'active' ? 'Disable' : 'Activate'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!items.length && <p className="admin-empty">No campaigns found.</p>}
        </div>
      </div>
    </div>
  );
}
