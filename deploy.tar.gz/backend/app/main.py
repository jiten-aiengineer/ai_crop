import hmac
import hashlib
from typing import Any, Literal
from uuid import UUID

from fastapi import FastAPI, Header, HTTPException, Query
from pydantic import BaseModel, Field
from psycopg.types.json import Jsonb

from .catalog_engine import recommend
from .config import (
    ASSISTANT_BURST_LIMIT,
    ASSISTANT_DAILY_LIMIT,
    GEMINI_SHADOW_ENABLED,
    GEMINI_SHADOW_MAX_ATTEMPTS,
    GEMINI_SHADOW_MODEL,
    INTERNAL_SERVICE_TOKEN,
    QWEN_ENABLED,
    QWEN_MAX_ATTEMPTS,
    QWEN_MODEL,
    QWEN_SHADOW_MODE,
)
from .db import connection
from .model_consensus import refresh_consensus
from .admin import router as admin_router
from .farmer_auth import router as farmer_auth_router
from .dealer_routes import router as dealer_router
from .coupon_routes import router as coupon_router


app = FastAPI(title="Crop Life AI API", version="0.1.0")
app.include_router(admin_router)
app.include_router(farmer_auth_router)
app.include_router(dealer_router)
app.include_router(coupon_router)


class InspectionContext(BaseModel):
    employee_code: str = Field(default='', max_length=32)
    collection_mode: Literal['general_employee', 'sales_officer'] = 'general_employee'
    crop: str = Field(default="", max_length=160)
    plant: str = Field(default="", max_length=160)
    description: str = Field(default="", max_length=4000)
    location: str = Field(default="", max_length=240)
    notes: str = Field(default="", max_length=4000)
    language: str = Field(default="en", min_length=2, max_length=12)


class StoredImage(BaseModel):
    bucket: str = Field(min_length=3, max_length=255)
    key: str = Field(min_length=1, max_length=1024)
    mime_type: str = Field(min_length=1, max_length=100)
    file_size_bytes: int = Field(gt=0, le=4 * 1024 * 1024)
    image_order: int = Field(ge=1, le=5)


class StorageFailure(BaseModel):
    image_order: int = Field(ge=1, le=5)
    code: Literal["upload_failed"]


class StoragePayload(BaseModel):
    status: Literal["not_configured", "stored", "partial_failure", "failed"]
    images: list[StoredImage] = Field(default_factory=list, max_length=5)
    failures: list[StorageFailure] = Field(default_factory=list, max_length=5)


class ProviderPayload(BaseModel):
    provider: Literal["gemma", "gemini", "qwen"]
    model: str = Field(min_length=1, max_length=120)
    success: bool
    latency_ms: int = Field(ge=0, le=120000)
    raw_json: dict[str, Any] = Field(default_factory=dict)
    error_message: str = Field(default="", max_length=2000)
    diagnosis: dict[str, Any] | None = None
    input_tokens: int | None = Field(default=None, ge=0)
    output_tokens: int | None = Field(default=None, ge=0)


class RecommendationPayload(BaseModel):
    product_id: str = Field(min_length=1, max_length=100)
    rank: int = Field(ge=1, le=20)
    match_score: float | None = Field(default=None, ge=0, le=1000)
    match_reason: str = Field(min_length=1, max_length=4000)
    match_tier: Literal["primary", "supporting"]


class InspectionPersistencePayload(BaseModel):
    inspection_id: UUID
    public_session_token: str = Field(default="", max_length=128)
    photo_count: int = Field(ge=1, le=5)
    context: InspectionContext
    storage: StoragePayload
    provider: ProviderPayload
    additional_providers: list[ProviderPayload] = Field(default_factory=list, max_length=2)
    recommendations: list[RecommendationPayload] = Field(default_factory=list, max_length=12)


class AssistantReservationPayload(BaseModel):
    employee_code: str = Field(default="", max_length=32)
    client_key_hash: str = Field(min_length=64, max_length=64, pattern=r"^[0-9a-f]{64}$")
    mode: Literal["crop", "company"] = "crop"
    provider: Literal["gemma"] = "gemma"
    model_name: str = Field(min_length=1, max_length=120)


class AssistantCompletionPayload(BaseModel):
    status: Literal["completed", "failed", "fallback"]
    input_tokens: int | None = Field(default=None, ge=0)
    output_tokens: int | None = Field(default=None, ge=0)
    latency_ms: int | None = Field(default=None, ge=0, le=120000)
    error_code: str = Field(default="", max_length=100)


def _require_internal_service_token(value: str | None):
    if not INTERNAL_SERVICE_TOKEN:
        raise HTTPException(status_code=503, detail="Inspection persistence is not configured.")
    if not value or not hmac.compare_digest(value, INTERNAL_SERVICE_TOKEN):
        raise HTTPException(status_code=401, detail="Inspection persistence is unauthorized.")


def _clean(value: Any, limit: int = 4000) -> str | None:
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value[:limit] or None


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [item.strip()[:1000] for item in value if isinstance(item, str) and item.strip()][:20]


def _confidence(value: Any) -> float | None:
    return float(value) if isinstance(value, (int, float)) and 0 <= value <= 1 else None


def _crop_id(conn, name: str | None):
    if not name:
        return None
    row = conn.execute("SELECT id FROM crops WHERE lower(name) = lower(%s) LIMIT 1", (name,)).fetchone()
    return row["id"] if row else None


def _problem_id(conn, issue_type: str | None, name: str | None):
    if not issue_type or not name:
        return None
    row = conn.execute(
        "SELECT id FROM problems WHERE issue_type = %s AND lower(name) = lower(%s) LIMIT 1",
        (issue_type, name),
    ).fetchone()
    return row["id"] if row else None


@app.get("/health")
def health():
    with connection() as conn:
        row = conn.execute("SELECT current_database() AS database").fetchone()
    return {"status": "ok", "database": row["database"]}


@app.post("/api/v1/assistant/reserve", status_code=201)
def reserve_assistant_request(
    payload: AssistantReservationPayload,
    x_inspection_persistence_token: str | None = Header(default=None),
):
    """Atomically reserve a privacy-limited daily/burst chat request.

    Chat text is deliberately not accepted or stored by this endpoint.
    """
    _require_internal_service_token(x_inspection_persistence_token)
    with connection() as conn:
        conn.execute("SELECT pg_advisory_xact_lock(hashtext(%s))", (payload.client_key_hash,))
        employee_id = None
        if payload.employee_code:
            employee = conn.execute(
                "SELECT id FROM employees WHERE employee_code=%s AND status <> 'inactive'",
                (payload.employee_code,),
            ).fetchone()
            employee_id = employee["id"] if employee else None
        usage = conn.execute(
            """
            SELECT
              count(*) FILTER (WHERE (created_at AT TIME ZONE 'Asia/Kolkata')::date =
                                     (now() AT TIME ZONE 'Asia/Kolkata')::date) AS used_today,
              count(*) FILTER (WHERE created_at >= now() - interval '1 minute') AS used_last_minute
            FROM assistant_requests WHERE client_key_hash=%s
            """,
            (payload.client_key_hash,),
        ).fetchone()
        if int(usage["used_today"] or 0) >= ASSISTANT_DAILY_LIMIT:
            raise HTTPException(429, f"Daily AI Assistant limit reached ({ASSISTANT_DAILY_LIMIT} messages). Try again tomorrow.")
        if int(usage["used_last_minute"] or 0) >= ASSISTANT_BURST_LIMIT:
            raise HTTPException(429, "Please wait a moment before sending another AI Assistant message.")
        row = conn.execute(
            """
            INSERT INTO assistant_requests(employee_id, client_key_hash, mode, provider, model_name)
            VALUES (%s, %s, %s, %s, %s) RETURNING id
            """,
            (employee_id, payload.client_key_hash, payload.mode, payload.provider, payload.model_name),
        ).fetchone()
        conn.commit()
    return {
        "request_id": str(row["id"]),
        "daily_limit": ASSISTANT_DAILY_LIMIT,
        "remaining_today": max(0, ASSISTANT_DAILY_LIMIT - int(usage["used_today"] or 0) - 1),
    }


@app.post("/api/v1/assistant/{request_id}/complete")
def complete_assistant_request(
    request_id: UUID,
    payload: AssistantCompletionPayload,
    x_inspection_persistence_token: str | None = Header(default=None),
):
    _require_internal_service_token(x_inspection_persistence_token)
    with connection() as conn:
        updated = conn.execute(
            """
            UPDATE assistant_requests SET status=%s, input_tokens=%s, output_tokens=%s,
                latency_ms=%s, error_code=%s, completed_at=now()
            WHERE id=%s RETURNING id
            """,
            (payload.status, payload.input_tokens, payload.output_tokens, payload.latency_ms,
             payload.error_code or None, request_id),
        ).fetchone()
        if not updated:
            raise HTTPException(404, "Assistant request was not found.")
        conn.commit()
    return {"request_id": str(request_id), "status": payload.status}


@app.get('/api/v1/field/identity')
def field_identity(x_inspection_persistence_token: str | None = Header(default=None), x_clsl_field_token: str | None = Header(default=None)):
    _require_internal_service_token(x_inspection_persistence_token)
    if not x_clsl_field_token or len(x_clsl_field_token) > 100:
        raise HTTPException(401, 'Open your personal field access link.')
    with connection() as conn:
        token_hash = hashlib.sha256(x_clsl_field_token.encode()).hexdigest()
        employee = conn.execute("""
            SELECT e.employee_code, e.full_name, e.office_email, e.office_mobile,
                   e.designation, e.department, e.location, roster.state, roster.territory,
                   'sales_officer' AS collection_mode, 4 AS minimum_images,
                   2 AS daily_inspection_target_min, 3 AS daily_inspection_target_max
            FROM field_access_grants grant_record
            JOIN employees e ON e.id=grant_record.employee_id
            JOIN sales_officer_territories roster ON roster.employee_id=e.id AND roster.status='active'
            WHERE grant_record.token_hash=%s AND grant_record.revoked_at IS NULL
              AND (grant_record.expires_at IS NULL OR grant_record.expires_at > now())
              AND e.status <> 'inactive'
            LIMIT 1
        """, (token_hash,)).fetchone()
        if employee:
            conn.execute("UPDATE field_access_grants SET last_used_at=now() WHERE token_hash=%s", (token_hash,))
            conn.commit()
    if not employee:
        raise HTTPException(401, 'Your field access is invalid or has been revoked. Request a new link from your administrator.')
    return employee


@app.get("/api/v1/catalog/products")
def list_products(
    search: str = Query(default="", max_length=120),
    category: str = Query(default="", max_length=80),
    limit: int = Query(default=50, ge=1, le=100),
):
    filters = ["p.status = 'active'", "p.approval_status = 'approved'"]
    params: list[object] = []
    if search.strip():
        params.append(f"%{search.strip()}%")
        filters.append(
            "(p.name ILIKE %s OR p.common_name ILIKE %s OR p.use_benefits ILIKE %s)"
        )
        params.extend([params[-1], params[-1]])
    if category.strip():
        params.append(category.strip())
        filters.append("pc.name = %s")
    params.append(limit)
    sql = f"""
        SELECT p.id, p.name, pc.name AS category, p.common_name, p.formulation,
               p.dose, p.use_benefits, p.packing, p.price_per_pack, p.application_method,
               p.safety_information, p.image_path, p.source_page,
               array_remove(array_agg(DISTINCT c.name), NULL) AS approved_crops
        FROM products p
        JOIN product_categories pc ON pc.id = p.category_id
        LEFT JOIN product_crop_mappings pcm
          ON pcm.product_id = p.id AND pcm.approval_status = 'approved'
        LEFT JOIN crops c ON c.id = pcm.crop_id AND c.status = 'active'
        WHERE {' AND '.join(filters)}
        GROUP BY p.id, pc.name
        ORDER BY p.name
        LIMIT %s
    """
    with connection() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {"items": rows, "count": len(rows)}


class CatalogRecommendationInput(BaseModel):
    crop: str = Field(default="", max_length=160)
    catalog_crop: str = Field(default="", max_length=160)
    likely_issue: str = Field(default="", max_length=300)
    issue_type: str = Field(default="", max_length=64)
    observed_symptoms: list[str] = Field(default_factory=list, max_length=30)
    probable_causes: list[str] = Field(default_factory=list, max_length=30)
    confidence: float | None = Field(default=None, ge=0, le=1)
    additional_information_required: bool = False
    issue_detected: bool = False


@app.post("/api/v1/catalog/recommendations")
def catalogue_recommendations(
    payload: CatalogRecommendationInput,
    x_inspection_persistence_token: str | None = Header(default=None),
):
    """Return recommendations from approved database catalogue records only."""
    _require_internal_service_token(x_inspection_persistence_token)
    with connection() as conn:
        items = recommend(conn, payload.model_dump())
    return {"items": items, "source": "approved_postgresql_catalogue"}


@app.post("/api/v1/inspections/persist", status_code=201)
def persist_inspection(
    payload: InspectionPersistencePayload,
    x_inspection_persistence_token: str | None = Header(default=None),
):
    """Persist a completed or failed web inspection after private S3 storage.

    This route is intentionally server-to-server only. It never receives or
    returns an S3 URL, and it is unavailable until a shared internal token is
    explicitly configured on both the frontend service and this API container.
    """
    _require_internal_service_token(x_inspection_persistence_token)
    if payload.context.collection_mode == 'sales_officer' and payload.photo_count < 4:
        raise HTTPException(422, 'Sales Officer inspections require all four structured crop photos.')
    declared_crop = _clean(payload.context.crop, 160)
    if payload.context.collection_mode == 'sales_officer' and not declared_crop:
        raise HTTPException(422, 'Sales Officer inspections require a selected crop.')
    diagnosis = payload.provider.diagnosis or {}
    detected_crop = _clean(diagnosis.get("crop"), 160)
    probable_issue = _clean(diagnosis.get("probable_issue"), 180)
    issue_type = _clean(diagnosis.get("issue_type"), 64) or "unknown"
    inspection_status = "completed" if payload.provider.success else "failed"
    failure_message = None if payload.provider.success else (_clean(payload.provider.error_message, 2000) or "AI provider failed.")

    with connection() as conn:
        crop_id = _crop_id(conn, declared_crop or detected_crop)
        employee_id = None
        farmer_id = None
        if payload.context.employee_code:
            employee = conn.execute("SELECT id FROM employees WHERE employee_code=%s AND status <> 'inactive'", (payload.context.employee_code,)).fetchone()
            if not employee:
                raise HTTPException(422, 'The field employee is not active.')
            employee_id = employee['id']
        if payload.public_session_token:
            public_user = conn.execute(
                """SELECT farmer_id FROM public_sessions
                   WHERE session_token=%s AND expires_at>now() AND revoked_at IS NULL""",
                (payload.public_session_token,),
            ).fetchone()
            if not public_user:
                raise HTTPException(422, 'The public user session is not valid.')
            farmer_id = public_user['farmer_id']
        conn.execute(
            """
            INSERT INTO inspections(
                id, employee_id, farmer_id, crop_id, farmer_crop_text, plant_text, symptom_notes,
                location_text, preferred_language, status, photo_count, failure_message,
                completed_at, image_storage_status, image_storage_failures,
                collection_mode, photo_requirements_met, photo_guidance_version,
                declared_crop_text, crop_source, diagnosis_confidence,
                ai_needs_more_information, dataset_quality_status, training_eligible
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                    CASE WHEN %s = 'completed' THEN now() ELSE NULL END, %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, 'awaiting_models', false)
            ON CONFLICT (id) DO UPDATE SET
                employee_id = COALESCE(inspections.employee_id, EXCLUDED.employee_id),
                farmer_id = COALESCE(inspections.farmer_id, EXCLUDED.farmer_id),
                crop_id = EXCLUDED.crop_id,
                farmer_crop_text = EXCLUDED.farmer_crop_text,
                plant_text = EXCLUDED.plant_text,
                symptom_notes = EXCLUDED.symptom_notes,
                location_text = EXCLUDED.location_text,
                preferred_language = EXCLUDED.preferred_language,
                status = EXCLUDED.status,
                photo_count = EXCLUDED.photo_count,
                failure_message = EXCLUDED.failure_message,
                completed_at = EXCLUDED.completed_at,
                image_storage_status = EXCLUDED.image_storage_status,
                image_storage_failures = EXCLUDED.image_storage_failures,
                collection_mode = EXCLUDED.collection_mode,
                photo_requirements_met = EXCLUDED.photo_requirements_met,
                photo_guidance_version = EXCLUDED.photo_guidance_version,
                declared_crop_text = EXCLUDED.declared_crop_text,
                crop_source = EXCLUDED.crop_source,
                diagnosis_confidence = EXCLUDED.diagnosis_confidence,
                ai_needs_more_information = EXCLUDED.ai_needs_more_information,
                updated_at = now()
            """,
            (
                payload.inspection_id,
                employee_id,
                farmer_id,
                crop_id,
                _clean(payload.context.crop, 160),
                _clean(payload.context.plant, 160),
                _clean(payload.context.description, 4000) or _clean(payload.context.notes, 4000),
                _clean(payload.context.location, 240),
                payload.context.language,
                inspection_status,
                payload.photo_count,
                failure_message,
                inspection_status,
                payload.storage.status,
                Jsonb([failure.model_dump() for failure in payload.storage.failures]),
                payload.context.collection_mode,
                payload.photo_count >= (4 if payload.context.collection_mode == 'sales_officer' else 1),
                'sales-field-v1' if payload.context.collection_mode == 'sales_officer' else None,
                declared_crop,
                ('field_officer' if declared_crop and payload.context.collection_mode == 'sales_officer'
                 else 'general_user' if declared_crop else 'ai_optional' if detected_crop else 'not_supplied'),
                _confidence(diagnosis.get("confidence")),
                diagnosis.get("needs_more_information") is True,
            ),
        )

        for image in payload.storage.images:
            conn.execute(
                """
                INSERT INTO inspection_images(
                    inspection_id, source, storage_provider, storage_bucket, storage_key,
                    original_filename, content_type, byte_size, image_order,
                    retention_status, consent_for_training, capture_role
                )
                VALUES (%s, 'upload', 's3', %s, %s, NULL, %s, %s, %s, 'retained', false, %s)
                ON CONFLICT (storage_key) DO UPDATE SET
                    storage_bucket = EXCLUDED.storage_bucket,
                    content_type = EXCLUDED.content_type,
                    byte_size = EXCLUDED.byte_size,
                    image_order = EXCLUDED.image_order,
                    capture_role = EXCLUDED.capture_role,
                    retention_status = 'retained',
                    deleted_at = NULL
                """,
                (
                    payload.inspection_id,
                    image.bucket,
                    image.key,
                    image.mime_type,
                    image.file_size_bytes,
                    image.image_order,
                    (['whole_plant', 'affected_part', 'symptom_closeup', 'alternate_angle', 'additional'][image.image_order - 1]
                     if payload.context.collection_mode == 'sales_officer' else None),
                ),
            )

        conn.execute(
            """
            INSERT INTO ai_provider_results(
                inspection_id, provider, model_name, success, latency_ms, raw_json, error_message
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (inspection_id, provider, model_name) DO UPDATE SET
                success = EXCLUDED.success,
                latency_ms = EXCLUDED.latency_ms,
                raw_json = EXCLUDED.raw_json,
                error_message = EXCLUDED.error_message,
                created_at = now()
            """,
            (
                payload.inspection_id,
                payload.provider.provider,
                payload.provider.model,
                payload.provider.success,
                payload.provider.latency_ms,
                Jsonb(payload.provider.raw_json),
                failure_message,
            ),
        )

        prediction_id = None
        provider_prediction_ids: dict[str, Any] = {}
        if payload.provider.success and payload.provider.diagnosis:
            prediction_crop_id = _crop_id(conn, declared_crop or detected_crop)
            problem_id = _problem_id(conn, issue_type, probable_issue)
            row = conn.execute(
                """
                INSERT INTO ai_predictions(
                    inspection_id, provider, model_name, prediction_role, crop_id, crop_text,
                    problem_id, issue_type, issue_name, severity, confidence, observed_symptoms,
                    probable_causes, alternative_possibilities, immediate_actions, prevention_tips,
                    additional_information_required, recommended_next_action, summary,
                    prompt_version, raw_response, latency_ms
                )
                VALUES (%s, %s, %s, 'primary', %s, %s, %s, %s, %s, %s, %s, %s,
                        %s, %s, %s, %s, %s, %s, %s, 'inspection-contract-v2', %s, %s)
                ON CONFLICT (inspection_id, provider, model_name, prediction_role) DO UPDATE SET
                    crop_id = EXCLUDED.crop_id,
                    crop_text = EXCLUDED.crop_text,
                    problem_id = EXCLUDED.problem_id,
                    issue_type = EXCLUDED.issue_type,
                    issue_name = EXCLUDED.issue_name,
                    severity = EXCLUDED.severity,
                    confidence = EXCLUDED.confidence,
                    observed_symptoms = EXCLUDED.observed_symptoms,
                    probable_causes = EXCLUDED.probable_causes,
                    alternative_possibilities = EXCLUDED.alternative_possibilities,
                    immediate_actions = EXCLUDED.immediate_actions,
                    prevention_tips = EXCLUDED.prevention_tips,
                    additional_information_required = EXCLUDED.additional_information_required,
                    recommended_next_action = EXCLUDED.recommended_next_action,
                    summary = EXCLUDED.summary,
                    raw_response = EXCLUDED.raw_response,
                    latency_ms = EXCLUDED.latency_ms
                RETURNING id
                """,
                (
                    payload.inspection_id,
                    payload.provider.provider,
                    payload.provider.model,
                    prediction_crop_id,
                    declared_crop or detected_crop,
                    problem_id,
                    issue_type,
                    probable_issue,
                    _clean(diagnosis.get("severity"), 32),
                    _confidence(diagnosis.get("confidence")),
                    Jsonb(_string_list(diagnosis.get("visible_symptoms"))),
                    Jsonb(_string_list(diagnosis.get("probable_causes"))),
                    Jsonb(_string_list(diagnosis.get("alternative_possibilities"))),
                    Jsonb(_string_list(diagnosis.get("immediate_actions"))),
                    Jsonb(_string_list(diagnosis.get("prevention_advice"))),
                    diagnosis.get("needs_more_information") is True,
                    _clean(diagnosis.get("recommended_next_action"), 4000),
                    _clean(diagnosis.get("summary"), 4000),
                    Jsonb(payload.provider.raw_json),
                    payload.provider.latency_ms,
                ),
            ).fetchone()
            prediction_id = row["id"]
            provider_prediction_ids[payload.provider.provider] = prediction_id

            conn.execute(
                """
                INSERT INTO ai_usage(inspection_id, prediction_id, employee_id, provider, model_name,
                                     operation, input_tokens, output_tokens, image_count,
                                     latency_ms, success, error_code)
                VALUES (%s, %s, %s, %s, %s, 'live_diagnosis', %s, %s, %s, %s, true, NULL)
                """,
                (payload.inspection_id, prediction_id, employee_id, payload.provider.provider,
                 payload.provider.model, payload.provider.input_tokens, payload.provider.output_tokens,
                 payload.photo_count, payload.provider.latency_ms),
            )
            refresh_consensus(conn, payload.inspection_id)

        # Gemma and Flash-Lite are now evaluated together in the live request.
        # Store the non-selected result as a shadow result so the dashboard has
        # both records immediately and the Flash-Lite worker does not repeat it.
        seen_providers = {payload.provider.provider}
        for extra in payload.additional_providers:
            if extra.provider in seen_providers:
                continue
            seen_providers.add(extra.provider)
            extra_failure = None if extra.success else (_clean(extra.error_message, 2000) or "AI provider failed.")
            conn.execute(
                """
                INSERT INTO ai_provider_results(
                    inspection_id, provider, model_name, success, latency_ms, raw_json, error_message
                ) VALUES (%s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (inspection_id, provider, model_name) DO UPDATE SET
                    success=EXCLUDED.success, latency_ms=EXCLUDED.latency_ms,
                    raw_json=EXCLUDED.raw_json, error_message=EXCLUDED.error_message, created_at=now()
                """,
                (payload.inspection_id, extra.provider, extra.model, extra.success,
                 extra.latency_ms, Jsonb(extra.raw_json), extra_failure),
            )
            if not extra.success or not extra.diagnosis:
                continue
            extra_diagnosis = extra.diagnosis
            extra_crop = _clean(extra_diagnosis.get("crop"), 160)
            extra_issue = _clean(extra_diagnosis.get("probable_issue"), 180)
            extra_issue_type = _clean(extra_diagnosis.get("issue_type"), 64) or "unknown"
            extra_row = conn.execute(
                """
                INSERT INTO ai_predictions(
                    inspection_id, provider, model_name, prediction_role, crop_id, crop_text,
                    problem_id, issue_type, issue_name, severity, confidence, observed_symptoms,
                    probable_causes, alternative_possibilities, immediate_actions, prevention_tips,
                    additional_information_required, recommended_next_action, summary,
                    prompt_version, raw_response, latency_ms
                ) VALUES (%s, %s, %s, 'shadow', %s, %s, %s, %s, %s, %s, %s, %s,
                          %s, %s, %s, %s, %s, %s, %s, 'inspection-contract-v2', %s, %s)
                ON CONFLICT (inspection_id, provider, model_name, prediction_role) DO UPDATE SET
                    crop_id=EXCLUDED.crop_id, crop_text=EXCLUDED.crop_text,
                    problem_id=EXCLUDED.problem_id, issue_type=EXCLUDED.issue_type,
                    issue_name=EXCLUDED.issue_name, severity=EXCLUDED.severity,
                    confidence=EXCLUDED.confidence, observed_symptoms=EXCLUDED.observed_symptoms,
                    probable_causes=EXCLUDED.probable_causes,
                    alternative_possibilities=EXCLUDED.alternative_possibilities,
                    immediate_actions=EXCLUDED.immediate_actions,
                    prevention_tips=EXCLUDED.prevention_tips,
                    additional_information_required=EXCLUDED.additional_information_required,
                    recommended_next_action=EXCLUDED.recommended_next_action,
                    summary=EXCLUDED.summary, raw_response=EXCLUDED.raw_response,
                    latency_ms=EXCLUDED.latency_ms
                RETURNING id
                """,
                (
                    payload.inspection_id, extra.provider, extra.model,
                    _crop_id(conn, declared_crop or extra_crop), declared_crop or extra_crop,
                    _problem_id(conn, extra_issue_type, extra_issue), extra_issue_type, extra_issue,
                    _clean(extra_diagnosis.get("severity"), 32), _confidence(extra_diagnosis.get("confidence")),
                    Jsonb(_string_list(extra_diagnosis.get("visible_symptoms"))),
                    Jsonb(_string_list(extra_diagnosis.get("probable_causes"))),
                    Jsonb(_string_list(extra_diagnosis.get("alternative_possibilities"))),
                    Jsonb(_string_list(extra_diagnosis.get("immediate_actions"))),
                    Jsonb(_string_list(extra_diagnosis.get("prevention_advice"))),
                    extra_diagnosis.get("needs_more_information") is True,
                    _clean(extra_diagnosis.get("recommended_next_action"), 4000),
                    _clean(extra_diagnosis.get("summary"), 4000),
                    Jsonb(extra.raw_json), extra.latency_ms,
                ),
            ).fetchone()
            extra_prediction_id = extra_row["id"]
            provider_prediction_ids[extra.provider] = extra_prediction_id
            conn.execute(
                """
                INSERT INTO ai_usage(inspection_id, prediction_id, employee_id, provider, model_name,
                                     operation, input_tokens, output_tokens, image_count,
                                     latency_ms, success, error_code)
                VALUES (%s, %s, %s, %s, %s, 'live_parallel_evaluation', %s, %s, %s, %s, true, NULL)
                """,
                (payload.inspection_id, extra_prediction_id, employee_id, extra.provider,
                 extra.model, extra.input_tokens, extra.output_tokens,
                 payload.photo_count, extra.latency_ms),
            )
        refresh_consensus(conn, payload.inspection_id)

        conn.execute("DELETE FROM inspection_recommendations WHERE inspection_id = %s", (payload.inspection_id,))
        if prediction_id:
            for recommendation in payload.recommendations:
                conn.execute(
                    """
                    INSERT INTO inspection_recommendations(
                        inspection_id, prediction_id, product_id, rank, match_score, match_reason, match_tier
                    )
                    SELECT %s, %s, %s, %s, %s, %s, %s
                    WHERE EXISTS (SELECT 1 FROM products WHERE id = %s)
                    ON CONFLICT (inspection_id, product_id) DO UPDATE SET
                        prediction_id = EXCLUDED.prediction_id,
                        rank = EXCLUDED.rank,
                        match_score = EXCLUDED.match_score,
                        match_reason = EXCLUDED.match_reason,
                        match_tier = EXCLUDED.match_tier,
                        shown_at = now()
                    """,
                    (
                        payload.inspection_id,
                        prediction_id,
                        recommendation.product_id,
                        recommendation.rank,
                        recommendation.match_score,
                        recommendation.match_reason,
                        recommendation.match_tier,
                        recommendation.product_id,
                    ),
                )
        shadow_states: list[str] = []
        immediate_gemini = next(
            (provider for provider in [payload.provider, *payload.additional_providers]
             if provider.provider == 'gemini' and provider.success and provider.diagnosis),
            None,
        )
        if immediate_gemini and provider_prediction_ids.get('gemini'):
            conn.execute(
                """
                INSERT INTO gemini_shadow_jobs(
                    inspection_id, model_name, status, attempt_count, max_attempts,
                    prediction_id, latency_ms, started_at, completed_at, next_attempt_at,
                    error_category, last_error, updated_at
                ) VALUES (%s, %s, 'completed', 1, %s, %s, %s, now(), now(), now(), NULL, NULL, now())
                ON CONFLICT (inspection_id) DO UPDATE SET
                    model_name=EXCLUDED.model_name, status='completed',
                    prediction_id=EXCLUDED.prediction_id, completed_at=now(),
                    latency_ms=EXCLUDED.latency_ms,
                    error_category=NULL, last_error=NULL, updated_at=now()
                """,
                (payload.inspection_id, immediate_gemini.model,
                 GEMINI_SHADOW_MAX_ATTEMPTS, provider_prediction_ids['gemini'],
                 immediate_gemini.latency_ms),
            )
            shadow_states.append("gemini:completed_live")
        elif (
            GEMINI_SHADOW_ENABLED
            and payload.provider.success
            and prediction_id
            and payload.storage.images
        ):
            queued = conn.execute(
                """
                INSERT INTO gemini_shadow_jobs(
                    inspection_id, model_name, status, max_attempts,
                    next_attempt_at, error_category, last_error, updated_at
                ) VALUES (%s, %s, 'pending', %s, now(), NULL, NULL, now())
                ON CONFLICT (inspection_id) DO UPDATE SET
                    model_name=EXCLUDED.model_name,
                    max_attempts=EXCLUDED.max_attempts,
                    status=CASE WHEN gemini_shadow_jobs.status IN ('completed','processing')
                                THEN gemini_shadow_jobs.status ELSE 'pending' END,
                    next_attempt_at=CASE WHEN gemini_shadow_jobs.status IN ('completed','processing')
                                         THEN gemini_shadow_jobs.next_attempt_at ELSE now() END,
                    error_category=CASE WHEN gemini_shadow_jobs.status IN ('completed','processing')
                                        THEN gemini_shadow_jobs.error_category ELSE NULL END,
                    last_error=CASE WHEN gemini_shadow_jobs.status IN ('completed','processing')
                                    THEN gemini_shadow_jobs.last_error ELSE NULL END,
                    updated_at=now()
                RETURNING status
                """,
                (payload.inspection_id, GEMINI_SHADOW_MODEL, GEMINI_SHADOW_MAX_ATTEMPTS),
            ).fetchone()
            shadow_states.append(f"gemini:{queued['status'] if queued else 'not_queued'}")
        elif GEMINI_SHADOW_ENABLED and payload.provider.success:
            shadow_states.append("gemini:no_s3_evidence")
        elif not GEMINI_SHADOW_ENABLED:
            shadow_states.append("gemini:disabled")
        if (
            QWEN_ENABLED
            and QWEN_SHADOW_MODE
            and payload.provider.success
            and prediction_id
            and payload.storage.images
        ):
            queued = conn.execute(
                """
                INSERT INTO qwen_shadow_jobs(
                    inspection_id, model_name, status, max_attempts,
                    next_attempt_at, error_category, last_error, updated_at
                ) VALUES (%s, %s, 'pending', %s, now(), NULL, NULL, now())
                ON CONFLICT (inspection_id) DO UPDATE SET
                    model_name = EXCLUDED.model_name,
                    max_attempts = EXCLUDED.max_attempts,
                    status = CASE
                        WHEN qwen_shadow_jobs.status IN ('completed', 'processing')
                            THEN qwen_shadow_jobs.status
                        ELSE 'pending'
                    END,
                    next_attempt_at = CASE
                        WHEN qwen_shadow_jobs.status IN ('completed', 'processing')
                            THEN qwen_shadow_jobs.next_attempt_at
                        ELSE now()
                    END,
                    error_category = CASE
                        WHEN qwen_shadow_jobs.status IN ('completed', 'processing')
                            THEN qwen_shadow_jobs.error_category
                        ELSE NULL
                    END,
                    last_error = CASE
                        WHEN qwen_shadow_jobs.status IN ('completed', 'processing')
                            THEN qwen_shadow_jobs.last_error
                        ELSE NULL
                    END,
                    updated_at = now()
                RETURNING status
                """,
                (payload.inspection_id, QWEN_MODEL, QWEN_MAX_ATTEMPTS),
            ).fetchone()
            shadow_states.append(f"qwen:{queued['status'] if queued else 'not_queued'}")
        elif QWEN_ENABLED and QWEN_SHADOW_MODE and payload.provider.success:
            shadow_states.append("qwen:no_s3_evidence")
        elif not (QWEN_ENABLED and QWEN_SHADOW_MODE):
            shadow_states.append("qwen:disabled")
        conn.commit()

    return {
        "status": "saved",
        "inspection_id": str(payload.inspection_id),
        "stored_images": len(payload.storage.images),
        "shadow_status": ";".join(shadow_states),
    }


@app.get('/api/i18n/login')
def get_i18n_login(lang: str = "en"):
    """Fetch localized strings for the login screen."""
    fallback = {
        "welcomeTitle": "Welcome!",
        "welcomeSub": "I am your smart crop doctor, ready to help.",
        "welcome": "Welcome to CLSL AI",
        "choose": "Choose your language",
        "account": "Join CLSL AI",
        "intro": "Unlock AI crop care, weather, products, rewards, and offers.",
        "firstName": "First name",
        "lastName": "Last name",
        "mobile": "Mobile number",
        "details": "Complete your login",
        "farmer": "Farmer",
        "dealer": "CLSL Dealer",
        "farmerBenefitTitle": "CLSL Farmer Benefits",
        "farmerBenefitText": "Farmers get offers and coupons on CLSL products. Get a referral code from your nearest CLSL dealer.",
        "dealerRecognised": "Dealer Mobile Recognised",
        "dealerRecognisedHelp": "Enter your CLSL dealer code to verify dealership.",
        "dealerCode": "Dealer Code",
        "referralCode": "Dealer Referral Code",
        "scanQr": "Scan Referral QR",
        "orEnterCode": "Or enter 7-letter code",
        "verify": "Verify",
        "verified": "Verified",
        "confirmDealer": "Confirm Dealership Details",
        "dealerConfirmed": "✓ Details verified",
        "otpButton": "Continue with OTP",
        "otpTitle": "Verify Mobile",
        "otpHelp": "TEST MODE: Enter 123456.",
        "otp": "6-digit OTP",
        "enter": "Enter CLSL AI",
        "back": "Back",
        "continue": "Continue",
        "wait": "Please wait...",
        "required": "Complete required fields.",
        "test": "Test login",
        "cityTerritory": "City / Territory",
        "owner": "Owner",
        "registeredMobile": "Registered Mobile",
        "mobileWarning": "This dealership is registered to another number.",
        "selectOne": "Select one",
        "requiredField": "Required"
    }
    if lang == "en":
        return fallback
    try:
        data = json.loads((Path(__file__).parent / "i18n_login.json").read_text(encoding="utf-8"))
        if lang in data:
            return data[lang]
    except Exception:
        pass
    return fallback
